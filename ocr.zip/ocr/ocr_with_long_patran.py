import cv2
import pytesseract
import re
import os
import sys
# Set up Tesseract OCR
pytesseract.pytesseract_cmd = "/usr/bin/tesseract"  # Update the path for Fedora if needed
def highlight_text(image, extracted_text):
    # Get data about the text, including bounding boxes
    data = pytesseract.image_to_data(image, lang="eng", output_type=pytesseract.Output.DICT)
    
    # Iterate through all detected text blocks
    n_boxes = len(data['text'])
    for i in range(n_boxes):
        if int(data['conf'][i]) > 0:  # Only process confident detections
            (x, y, w, h) = (data['left'][i], data['top'][i], data['width'][i], data['height'][i])
            # Draw a rectangle around the text
            cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)

    return image

def extract_and_highlight_text(image_path):
    try:
        # Load the image
        image = cv2.imread(image_path)
        
        if image is None:
            raise ValueError(f"Cannot load image: {image_path}")

        image_name = os.path.basename(image_path)
        # Resize the image to increase DPI
        max_width, max_height = 2000, 2000
        h, w = image.shape[:2]
        if w > max_width or h > max_height:
            scaling_factor = min(max_width / w, max_height / h)
            image = cv2.resize(image, (int(w * scaling_factor), int(h * scaling_factor)))
        elif w > 3000 or h > 3000:
            scaling_factor = min(3000 / w, 3000 / h)
            image = cv2.resize(image, (int(w * scaling_factor), int(h * scaling_factor)))
        else:
            scaling_factor = 1.0

         # Detect orientation and rotate the image
        osd = pytesseract.image_to_osd(image)
        
        """ rotation_angle = int(re.search(r'Rotate: (\d+)', osd).group(1))
        
        #print(f"Rotation Angle: {rotation_angle}")
        #sys.exit()
        
        if rotation_angle != 0:
            (h, w) = image.shape[:2]
            center = (w // 2, h // 2)
            matrix = cv2.getRotationMatrix2D(center, -rotation_angle, 1.0)
            image = cv2.warpAffine(image, matrix, (w, h)) """

         # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (4, 4))
        cleaned = cv2.morphologyEx(gray, cv2.MORPH_OPEN, kernel)
        equalized = cv2.equalizeHist(gray)

        # Initialize `consignment_number` to None
        consignment_number = None

        _, thresh = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY)
        
        # Remove noise that could interfere with text extraction.by  GaussianBlur
        blur = cv2.GaussianBlur(thresh, (3, 3), 1)

        #cv2.imshow("Highlighted Image", image)
        #cv2.waitKey(0)
        # Extract text
        
        extracted_text = pytesseract.image_to_string(thresh, lang="eng")
        # Display image with highlighted text for specific images
        highlighted_image = highlight_text(gray, extracted_text)
        print(f"Extracted Text: {extracted_text}")
        #sys.exit()
        # Highlight extracted_text text
        cv2.imshow("Highlighted Image", highlighted_image)
        cv2.waitKey(0)
        sys.exit()
        
        
        

        consignment_number = None
        primary_patterns = [
            r"PLK-\d+",
            r"PNP-\d+",
            r"SGN-\d+",
            r"MTH-\d+",
            r"GZB-\d+",
            r"ALG-\d+",
            r"FBD-\d+",
            r"AGR-\d+",
            r"PNP-\d+",
            r"MZN-\d+",
            r"BLT-\d+",
            r"DDN-\d+",
            r"NDA-\d+",
            r"ZYS-\d+",
            r"DOKR-\d+",
            r"PLK-\s*\d+",
            r"ZYS-\s*\d+",
            r"PNP-\s*\d+",
            r"SGN-\s*\d+",
            r"MTH-\s*\d+",
            r"GZB-\s*\d+",
            r"ALG-\s*\d+",
            r"FBD-\s*\d+",
            r"AGR-\s*\d+",
            r"PNP-\s*\d+",
            r"MZN-\s*\d+",
            r"BLT-\s*\d+",
            r"DDN-\s*\d+",
            r"ZYS-\s*\d+",
            r"NDA-\s*\d+",
            r"DOKR-\s*\d+",
        ]
        # NEED TO FIND TEXT CONTAINING THE ABOVE PATTERN
        for pattern in primary_patterns:
            match = re.search(pattern, extracted_text, re.IGNORECASE)
            if match:
                consignment_number = match.group(0)
                 #if(image_name=='f328916464.jpg'):
                print(f"Consignment Number: {consignment_number}")
                #sys.exit()
                break
            else:
                continue
       
        
        # Search for consignment numbers using regex if consignment_number is None
        if not consignment_number:
            # EXCLUDED LIST if that ooccurs i want to fetch its next closest text or number
            EXCLUDED_LIST = ['NO', 'NUMBER', 'NO.','ied]', 'NO','NE.','Ne','No','Te','NOTICE','JAG','GSTIN','the','of','and','to','in','for','on','with','by','at','or','as','an','a','is','are','it','this','that','these','those','be','will','would','should','can','could','may','might','must','shall','have','has','had','do','does','did','am','is','are','was','were','being','been','get','got','getting','gets','give','gave','given','giving','go','goes','went','gone','going','make','made','making','makes','put','puts','putting','say','says','said','saying','see','saw','seen','seeing','seem','seems','seemed','seeming','take','took','taken','taking','come','came','coming','comes','become','became','becoming','becomes','begin','began','begun','beginning','bring','brought','bringing','brings','keep','kept','keeping','keeps','hold','held','holding','holds','hear','heard','hearing','hears','let','lets','letting','let','make','made','making','makes','put','puts','putting','put','set','setting','sets','set','show','showed','shown','showing','show','try','tries','tried','trying','try','help','helps','helped','helping','help','work','works','worked','working','work','call','calls','called','calling','call','ask','asks','asked','asking','ask','need','needs','needed','needing','need','feel','feels','felt','feeling','feel','become','becomes','became','becoming','become','leave','leaves','left','leaving','leave','put','puts','putting','put','mean','means','meant','meaning','mean','keep','keeps','kept','keeping','keep','let','lets','letting','let','begin','begins','began','beginning','begin','seem','seems','seemed','seeming','seem','do','does','did','doing','do','have','has','had','having','have','say','says','said','saying','say','go','goes','went','going','go','get']
            patterns = [
                r"CONSIGNMENT\s*NOTE\s*[:\-]?\s*([^\s]+)",
                r"DOCKET\s*NUMBER\s*[:\-]?\s*([^\s]+)",
                r"DOCKT\s*NUMBER\s*[:\-]?\s*([^\s]+)",
                r"DOCET\s*NUMBER\s*[:\-]?\s*([^\s]+)",
                r"DOCKET\s*NMBER\s*[:\-]?\s*([^\s]+)",
                r"CONSIGNMENT\s*NO\s*[:\-]?\s*([^\s]+)",
                r"CONSIGNMENT\s*NUMBER\s*[:\-]?\s*([^\s]+)",
                r"C\/N\s*[:\-]?\s*([^\s]+)",
                r"GRN\s*[:\-]?\s*([^\s]+)",
                r"GR\.?NO\.?\s*[:\-]?\s*([^\s]+)",
                r"GR\s*NUMBER\s*[:\-]?\s*([^\s]+)",
                r"GR\s*NO\s*[:\-]?\s*([^\s]+)",
                r"GR-NO\s*[:\-]?\s*([^\s]+)",
                r"CN\.?NO\.?\s*[:\-]?\s*([^\s]+)",
                r"CN\s*NUMBER\s*[:\-]?\s*([^\s]+)"
            ]

            for pattern in patterns:
                match = re.search(pattern, extracted_text, re.IGNORECASE)
                if match:
                       
                        consignment_number = match.group(1).strip()
            
                        if match:
                            consignment_number = match.group(1).strip()

                            # Check if candidate is in the excluded list
                            if consignment_number.upper() in [word.upper() for word in EXCLUDED_LIST]:
                                # Fetch the next closest text or number
                                match_end = match.end()  # End position of the current match
                                remaining_text = extracted_text[match_end:].strip()  # Text after the match
                                
                                # Find the next closest valid match
                                next_match = re.search(r"[A-Z0-9\-]+", remaining_text)
                                if next_match:
                                    next_candidate = next_match.group(0).strip()
                                    # Check if the next candidate is valid
                                    if next_candidate.upper() not in [word.upper() for word in EXCLUDED_LIST]:
                                        consignment_number = next_candidate
                            else:
                                print(f"Match: {consignment_number}")
                                #return consignment_number  # Return the valid candidate if not excluded


                        #print(f"Match: {consignment_number}")
                        # if not a number then cheack the sting contain a - and a number after that if not search for next pattern
                        try:
                            if not consignment_number.isnumeric():
                                print(f"Consignment Number: {consignment_number}")
                                if '-' in consignment_number:
                                    consignment_number_has_num = consignment_number.split('-')[-1]
                                    if consignment_number_has_num.isnumeric():
                                        print(f"Consignment Number RAT: {consignment_number}")
                                        break
                                else:
                                    continue
                            elif consignment_number.isnumeric():
                                #if image_name == 'f328916464.jpg':
                                print(f"Consignment Number BAT: {consignment_number}")
                                break
                            else:
                                print(f"Consignment Number SAT: {consignment_number}")
                                continue
                        except Exception as e:
                            print(f"Error processing consignment number: {e}")
                            consignment_number = None

        
        # Regex pattern for GSTIN
        gstin_pattern = r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$'
 
        # Handle case when no consignment number is found or if the consignment number is a GSTIN or length is less than 3
        if not consignment_number:
            #print(f"No consignment number found in {image_name}")
            return None

       
        return consignment_number

    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return None

# Process directories in the current directory
current_dir = os.getcwd()
subdirs = [os.path.join(current_dir, d) for d in os.listdir(current_dir) if os.path.isdir(os.path.join(current_dir, d))]

# Directory containing images
image_dir = "./undetected"


# Process each "undetected" directory inside subdirectories
for subdir in subdirs:
    # Ensure the directory exists
    image_dir = os.path.join(subdir, "undetected")
    if not os.path.exists(image_dir):
        continue

    print(f"\nProcessing directory: {subdir}")
    #sys.exit()
    # Process all images in the directory
    results = {}
    for filename in os.listdir(image_dir):
        file_path = os.path.join(image_dir, filename)
        
        # Check if the file is an image
        if os.path.isfile(file_path) and filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
            print(f"Processing {file_path}...")
            consignment_number = extract_and_highlight_text(file_path)
            if consignment_number:
                # append to log file
                with open("consignment_numbers.txt", "a") as f:
                    f.write(f"{file_path}: {consignment_number}\n")
                # file to subdirectory with consignment number as file name
                image_extension = os.path.splitext(filename)[1]
                new_file_path = os.path.join(subdir, f"{consignment_number}{image_extension}")
                #os.rename(file_path, new_file_path)


# Display results
""" print("\nExtracted Consignment Numbers:")
for filename, consignment_number in results.items():
    if consignment_number:
        print(f"{filename}: {consignment_number}")
    else:
        print(f"{filename}: No consignment number detected.")

# Save results to a file
output_file = "consignment_numbers.txt"
with open(output_file, "w") as f:
    for filename, consignment_number in results.items():
        f.write(f"{filename}: {consignment_number if consignment_number else 'Not Found'}\n")

print(f"\nResults saved to {output_file}") """
