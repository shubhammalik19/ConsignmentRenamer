import os
import shutil

# List of supported image formats
SUPPORTED_FORMATS = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp"}

# Function to consolidate image files into the 'cat' directory
def consolidate_images():
    current_dir = os.getcwd()
    target_dir = os.path.join(current_dir, "cat")

    # Create the target directory if it doesn't exist
    os.makedirs(target_dir, exist_ok=True)

    total_files_moved = 0

    # Walk through the directory structure
    for root, _, files in os.walk(current_dir):
        # Skip the target directory itself
        if root.startswith(target_dir):
            continue

        # Extract the relative path, excluding the first-level directory
        relative_root = os.path.relpath(root, current_dir).split(os.sep, 1)
        adjusted_relative_path = relative_root[1] if len(relative_root) > 1 else ""

        for file in files:
            # Check if the file has a supported image extension
            if os.path.splitext(file)[1].lower() in SUPPORTED_FORMATS:
                source_path = os.path.join(root, file)

                # If the file is directly in a directory (no subdirectory), move it directly to 'cat'
                if not adjusted_relative_path:
                    destination_path = os.path.join(target_dir, file)
                else:
                    # Otherwise, preserve the subdirectory structure in 'cat'
                    destination_dir = os.path.join(target_dir, adjusted_relative_path)
                    os.makedirs(destination_dir, exist_ok=True)
                    destination_path = os.path.join(destination_dir, file)

                try:
                    # Move the file
                    shutil.move(source_path, destination_path)
                    print(f"Moved: {source_path} -> {destination_path}")
                    total_files_moved += 1
                except Exception as e:
                    print(f"Error moving {source_path} to {destination_path}: {e}")

    print(f"\nSummary: {total_files_moved} files moved to {target_dir}")

# Run the script
if __name__ == "__main__":
    consolidate_images()
