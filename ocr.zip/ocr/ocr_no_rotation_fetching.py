import cv2
import pytesseract
import re
import os
import sys
# Set up Tesseract OCR
pytesseract.pytesseract_cmd = "/usr/bin/tesseract"  # Update the path for Fedora if needed

def extract_and_highlight_text(image_path):
    try:
        # Load the image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Cannot load image: {image_path}")

        image_name = os.path.basename(image_path)
        # Resize the image to increase DPI
        max_width, max_height = 2000, 2000
        h, w = image.shape[:2]
        if w > max_width or h > max_height:
            scaling_factor = min(max_width / w, max_height / h)
            image = cv2.resize(image, (int(w * scaling_factor), int(h * scaling_factor)))
        elif w > 3000 or h > 3000:
            scaling_factor = min(3000 / w, 3000 / h)
            image = cv2.resize(image, (int(w * scaling_factor), int(h * scaling_factor)))
        else:
            scaling_factor = 1.0

         # Detect orientation and rotate the image
        osd = pytesseract.image_to_osd(image)
        rotation_angle = int(re.search(r'Rotate: (\d+)', osd).group(1))
        
        #print(f"Rotation Angle: {rotation_angle}")
        #sys.exit()
        
        """  if rotation_angle != 0:
                (h, w) = image.shape[:2]
                center = (w // 2, h // 2)
                matrix = cv2.getRotationMatrix2D(center, -rotation_angle, 1.0)
                image = cv2.warpAffine(image, matrix, (w, h)) """

         # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
        cleaned = cv2.morphologyEx(gray, cv2.MORPH_OPEN, kernel)
        equalized = cv2.equalizeHist(gray)

        # Initialize `consignment_number` to None
        consignment_number = None

        # Preprocessing steps
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        _, thresh = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
        thresh = cv2.GaussianBlur(thresh, (3, 3), 0)

        # Remove noise that could interfere with text extraction.by  GaussianBlur
        blur = cv2.GaussianBlur(thresh, (3, 3), 0)

        #cv2.imshow("Highlighted Image", image)
        #cv2.waitKey(0)
        # Extract text
        
        extracted_text = pytesseract.image_to_string(thresh, lang="eng")
       
        # Highlight detected text
        data = pytesseract.image_to_data(thresh, output_type=pytesseract.Output.DICT)
       
        """  for i in range(len(data['text'])):
                if consignment_number in data['text'][i]:
                    x, y, w, h = data['left'][i], data['top'][i], data['width'][i], data['height'][i]
                    cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 2)
            if image_name in ['f318852968.jpg', 'E-1.jpg', '100.jpg']:
            sys.exit() """
        # Display image with highlighted text for specific images
        #if image_name in ['f318952632.jpg', 'E-1.jpg', '100.jpg']:
        #print(f"Extracted Text: {extracted_text}")
        #cv2.imshow("Highlighted Image", image)
        #cv2.waitKey(0)
        #cv2.destroyAllWindows()
        
        #print(f"Extracted Text: {extracted_text}")

        consignment_number = None
        primary_patterns = [
            r"PLK-\d+",
            r"PNP-\d+",
            r"SGN-\d+",
            r"MTH-\d+",
            r"GZB-\d+",
            r"ALG-\d+",
            r"FBD-\d+",
            r"AGR-\d+",
            r"PNP-\d+",
            r"MZN-\d+",
            r"BLT-\d+",
            r"DDN-\d+",
            r"NDA-\d+",
            r"ZYS-\d+",
            r"PLK-\s*\d+",
            r"ZYS-\s*\d+",
            r"PNP-\s*\d+",
            r"SGN-\s*\d+",
            r"MTH-\s*\d+",
            r"GZB-\s*\d+",
            r"ALG-\s*\d+",
            r"FBD-\s*\d+",
            r"AGR-\s*\d+",
            r"PNP-\s*\d+",
            r"MZN-\s*\d+",
            r"BLT-\s*\d+",
            r"DDN-\s*\d+",
            r"ZYS-\s*\d+",
            r"NDA-\s*\d+",
        ]
        # NEED TO FIND TEXT CONTAINING THE ABOVE PATTERN
        for pattern in primary_patterns:
            match = re.search(pattern, extracted_text, re.IGNORECASE)
            if match:
                consignment_number = match.group(0)
                 #if(image_name=='f328916464.jpg'):
                print(f"Consignment Number: {consignment_number}")
                #sys.exit()
                break
            else:
                continue
  
        # Handle case when no consignment number is found
        if not consignment_number:
            #print(f"No consignment number found in {image_name}")
            return None

       
        return consignment_number

    except Exception as e:
        print(f"Error processing {image_path}: {e}")
        return None

# Process directories in the current directory
current_dir = os.getcwd()
subdirs = [os.path.join(current_dir, d) for d in os.listdir(current_dir) if os.path.isdir(os.path.join(current_dir, d))]

# Directory containing images
image_dir = "./undetected"


# Process each "undetected" directory inside subdirectories
for subdir in subdirs:
    # Ensure the directory exists
    image_dir = os.path.join(subdir, "undetected")
    if not os.path.exists(image_dir):
        continue

    print(f"\nProcessing directory: {subdir}")
    #sys.exit()
    # Process all images in the directory
    results = {}
    for filename in os.listdir(image_dir):
        file_path = os.path.join(image_dir, filename)
        
        # Check if the file is an image
        if os.path.isfile(file_path) and filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
            print(f"Processing {file_path}...")
            consignment_number = extract_and_highlight_text(file_path)
            if consignment_number:
                # append to log file
                with open("consignment_numbers.txt", "a") as f:
                    f.write(f"{file_path}: {consignment_number}\n")
                # file to subdirectory with consignment number as file name
                image_extension = os.path.splitext(filename)[1]
                new_file_path = os.path.join(subdir, f"{consignment_number}{image_extension}")
                os.rename(file_path, new_file_path)


# Display results
""" print("\nExtracted Consignment Numbers:")
for filename, consignment_number in results.items():
    if consignment_number:
        print(f"{filename}: {consignment_number}")
    else:
        print(f"{filename}: No consignment number detected.")

# Save results to a file
output_file = "consignment_numbers.txt"
with open(output_file, "w") as f:
    for filename, consignment_number in results.items():
        f.write(f"{filename}: {consignment_number if consignment_number else 'Not Found'}\n")

print(f"\nResults saved to {output_file}") """
