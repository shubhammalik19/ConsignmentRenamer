from google.cloud import vision
from google.protobuf.json_format import MessageToDict
import os
import re
import sys
from PIL import Image
import db_connector
import shutil

# Establish a connection
db_connection = db_connector.connect_to_database()

from datetime import datetime

def get_financial_year_start_date(CONSIGNMENT_DATE):
    """
    Returns the start date of the financial year based on the given consignment date.
    Financial year starts on April 1.
    
    :param CONSIGNMENT_DATE: A string representing the date in "DD/MM/YYYY" or "DD-MM-YYYY" format.
    :return: A string representing the financial year's start date in "DD/MM/YYYY" format.
    """
    #print(f"START RUNNING FIN: {CONSIGNMENT_DATE}")
    try:
        # Normalize the date format
        CONSIGNMENT_DATE = CONSIGNMENT_DATE.replace("-", "/")
        #print(f"CONSIGNMENT_DATE: {CONSIGNMENT_DATE}")
        consignment_date_obj = datetime.strptime(CONSIGNMENT_DATE, "%d/%m/%Y")
        #print(f"consignment_date_obj: {consignment_date_obj}")
        # Extract the year and month from the date
        year = consignment_date_obj.year
        month = consignment_date_obj.month
        
        # Determine the financial year start date
        if month >= 4:  # From April to December, the financial year starts on April 1 of the same year
            start_date = datetime(year, 4, 1)
        else:  # From January to March, the financial year starts on April 1 of the previous year
            start_date = datetime(year - 1, 4, 1)

        # Return the start date in YYYY-M-D format
        #print(f"Financial Year Start Date: {start_date.strftime('%Y-%m-%d')}")
        return start_date.strftime("%Y-%m-%d")
    except Exception as e:
        print(f"Error processing financial year start date: {e}")
        return None


# Test the function
def handle_file_move(file_path, company_folder, financial_year, consignment_number, image_dir):
    """
    Handles moving or copying files to their designated directories.
    """
    try:
        company_folder_path = os.path.join(image_dir, company_folder)
        if financial_year and company_folder!='SEPRATE' and company_folder!='DISCARD' and company_folder!='jag':
            company_folder_path = os.path.join(company_folder_path, financial_year)
        
        os.makedirs(company_folder_path, exist_ok=True)
        new_file_path = os.path.join(company_folder_path, f"{consignment_number}.jpg")
        
        if not os.path.exists(new_file_path):
            #shutil.move(file_path, new_file_path)
            #print(f"File moved to: {new_file_path}")
            pass
        else:
            # rename file in current directory
            new_file_path = os.path.join(image_dir, f"{consignment_number}.jpg")
            #shutil.move(file_path, new_file_path)
            #print(f"File already exists: {new_file_path}")
        
        return new_file_path
    except Exception as e:
        print(f"Error handling file move: {e}")
        return None
    
# insert in logst find lost found consignment_number  ,  file_path , is_org , gr_date , company
def insert_into_table(consignment_number, file_path, is_org, gr_date, company):
    global db_connection
    """
    Inserts the extracted data into the 'lost' table in the database.

    :param consignment_number: The consignment number to insert.
    :param file_path: The file path associated with the consignment.
    :param is_org: Indicates if the record is original (1 or 0).
    :param gr_date: GR date in 'DD/MM/YYYY' format.
    :param company: Company name associated with the consignment.
    """
    try:
        # Convert gr_date to 'YYYY-MM-DD' format if provided
        formatted_gr_date = None
        if gr_date:
            try:
                formatted_gr_date = datetime.strptime(gr_date, "%d/%m/%Y").strftime("%Y-%m-%d")
            except ValueError:
                print(f"Invalid GR date format: {gr_date}")
                formatted_gr_date = None
         # Ensure database connection is active
        if db_connection is None or not db_connection.is_connected():
            print("Reconnecting to the database...")
            db_connection = db_connector.connect_to_database()
            if db_connection is None:
                print("Failed to establish database connection.")
                return

        # SQL query to insert data
        query = """
            INSERT INTO lost (
                consignment_number, file_path, is_org, gr_date, company
            ) VALUES (%s, %s, %s, %s, %s);
        """
        
        # Execute the query
        cursor = db_connection.cursor(buffered=True)
        cursor.execute(query, (
            consignment_number, 
            file_path, 
            is_org, 
            formatted_gr_date, 
            company
        ))

        # Commit the transaction
        db_connection.commit()
        #print("Data inserted successfully.")
    except Exception as e:
        #print(f"Error inserting data for consignment number {consignment_number}: {e}")
        db_connection.rollback()
    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()

def update_file_path_in_table(table_name, is_org, consignment_number, file_path, CONSIGNMENT_DATE):
    global db_connection
    """
    Updates the file_path in the specified table based on the consignment number and date.

    :param table_name: The name of the table to update.
    :param is_org: Flag indicating whether the record is original.
    :param consignment_number: The consignment number to update.
    :param file_path: The new file path to set.
    :param CONSIGNMENT_DATE: The consignment date for filtering the financial year start date.
    """
    START_DATE = None
    if CONSIGNMENT_DATE:
        START_DATE = get_financial_year_start_date(CONSIGNMENT_DATE)
    
    try:
        if not table_name:
            #print("Table name is required. Inserting into a default table.")
            insert_into_table(consignment_number, file_path, is_org, None, None)
            return
         # Ensure database connection is active
        if db_connection is None or not db_connection.is_connected():
            print("Reconnecting to the database...")
            db_connection = db_connector.connect_to_database()
            if db_connection is None:
                print("Failed to establish database connection.")
                return

        # Create a cursor
        cursor = db_connection.cursor(buffered=True)
        
        # Determine the query based on START_DATE
        if START_DATE:
            query = f"""
            UPDATE {table_name}
            SET file_path = %s
            WHERE gr_no = %s AND gr_date >= %s;
            """
            params = (file_path, consignment_number, START_DATE)
        else:
            query = f"""
            UPDATE {table_name}
            SET file_path = %s
            WHERE gr_no = %s;
            """
            params = (file_path, consignment_number)

        # Execute the query
        cursor.execute(query, params)
        db_connection.commit()
        #print("File path updated successfully.")
    except Exception as e:
        #print(f"Error updating file path for {consignment_number} in {table_name}: {e}")
        db_connection.rollback()
    finally:
        if 'cursor' in locals() and cursor:  # Ensure the cursor is closed
            cursor.close()



        
# log file_path as image_path consignment_number , response  gr_date company in table  `log`
def log_data(image_path, consignment_number, response, gr_date, company, message='', text=''):
    global db_connection
    """
    Logs the extracted data to the database.

    :param image_path: Path to the image being processed.
    :param consignment_number: Extracted consignment number.
    :param response: Response or file path after processing.
    :param gr_date: GR date in 'DD/MM/YYYY' format.
    :param company: Extracted company name.
    :param message: Custom message for logging.
    :param text: Optional text content extracted.
    """
    try:
        # Ensure database connection is active
        if db_connection is None or not db_connection.is_connected():
            print("Reconnecting to the database...")
            db_connection = db_connector.connect_to_database()
            if db_connection is None:
                print("Failed to establish database connection.")
                return

        # Determine if the 'text' field has content
        is_text = 1 if text else 0

        # Default response if not provided
        response = response or "No response"

        # Convert GR date to 'YYYY-MM-DD' format if provided
        formatted_gr_date = None
        if gr_date:
            try:
                formatted_gr_date = datetime.strptime(gr_date, "%d/%m/%Y").strftime("%Y-%m-%d")
            except ValueError:
                print(f"Invalid GR date format: {gr_date}")
                formatted_gr_date = None

        # SQL query to insert log data
        query = """
            INSERT INTO log (
                file_path, consignment_number, response, gr_date, company, message, text, is_text
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
        """

        # Use a context manager for the cursor
        with db_connection.cursor(buffered=True) as cursor:
            # Sanitize text content
            sanitized_text = db_connection.converter.escape(text) if text else ''
            cursor.execute(query, (
                image_path,
                consignment_number,
                response,
                formatted_gr_date,
                company,
                message,
                sanitized_text,
                is_text
            ))

        # Commit the transaction
        db_connection.commit()
        print(f"Data logged successfully for consignment number {consignment_number}.")

    except Exception as e:
        # Log detailed error for debugging
        """ print(
            f"Error logging data for consignment number {consignment_number}: {e}\n"
            f"Details -> image_path: {image_path}, response: {response}, gr_date: {gr_date}, "
            f"company: {company}, message: {message}, text: {text}"
        ) """
        if db_connection:
            db_connection.rollback()

    finally:
        # Ensure database connection cleanup
        if db_connection and db_connection.is_connected():
            pass
            #print("Database connection is active.")


     
# cheack gr no from $table name
def fetch_gr_no_IN_ORG_from_table(consignment_number, table_name):
    global db_connection
    """
    Checks if a consignment number exists in the specified table with `is_org = 1`.

    :param consignment_number: The consignment number to search for.
    :param table_name: The name of the database table.
    :return: True if a matching record is found, False otherwise.
    """
    if not table_name:
        table_name = 'jagdamba'  # Default table name
        

    try:
        # Query to check for the GR No. with `is_org` = 1
        query = f"SELECT 1 FROM {table_name} WHERE gr_no = %s AND `is_org` = 1 LIMIT 1;"
        cursor = db_connection.cursor(buffered=True)  # Use buffered cursor

        # Execute the query
        cursor.execute(query, (consignment_number,))
        result = cursor.fetchone()
        return bool(result)  # Return True if a result is found, otherwise False
    except Exception as e:
        print(f"Error fetching GR No. for {consignment_number} in {table_name}: {e}")
        return None
    finally:
        if 'cursor' in locals() and cursor:  # Ensure the cursor is closed
            cursor.close()
# cheack gr no from jagdamba where is_direct=1 if date is not provided the fetch all gr_date >= financial year start date
def is_direct_consignment(consignment_number, CONSIGNMENT_DATE):
    global db_connection
    """
    Checks if a consignment number is a direct consignment in the 'jagdamba' table.

    :param consignment_number: The consignment number to search for.
    :param CONSIGNMENT_DATE: The consignment date for filtering the financial year start date.
    :return: A dictionary containing consignment details if direct, or None otherwise.
    """
    START_DATE = get_financial_year_start_date(CONSIGNMENT_DATE)  # Get the financial year start date

    try:
        # Prepare the database cursor
         # Ensure database connection is active
        if db_connection is None or not db_connection.is_connected():
            print("Reconnecting to the database...")
            db_connection = db_connector.connect_to_database()
            if db_connection is None:
                print("Failed to establish database connection.")
                return None
        cursor = db_connection.cursor(buffered=True, dictionary=True)
        
        # Define the query and parameters
        query = """
            SELECT * FROM jagdamba
            WHERE number = %s AND is_direct = 1 AND is_org = 0 AND is_done = 0
        """
        params = [consignment_number]
        
        # Add date filtering if START_DATE is provided
        if START_DATE:
            query += " AND gr_date >= %s"
            params.append(START_DATE)

        query += " LIMIT 1;"

        # Execute the query
        cursor.execute(query, params)
        result = cursor.fetchone()

        # If a result is found, mark it as done
        if result:
            update_query = "UPDATE jagdamba SET is_done = 1 WHERE id = %s;"
            cursor.execute(update_query, (result['id'],))
            db_connection.commit()
            #print(f"Direct consignment {consignment_number} marked as done.")
      
        return result
    except Exception as e:
        print(f"Error checking direct consignment for {consignment_number}: {e}")
        db_connection.rollback()
        return None
    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()  # Ensure the cursor is always closed

# cheack gr no from $table name
def fetch_gr_no_from_table(consignment_number, table_name):
    global db_connection
    """
    Fetches the GR No. from the database table based on the consignment number.
    """
    if not table_name:
        table_name = 'jagdamba'  # Default table name

    try:
        query = f"SELECT gr_no FROM {table_name} WHERE gr_no = %s;"
        cursor = db_connection.cursor(buffered=True)  # Use a buffered cursor
        cursor.execute(query, (consignment_number,))
        result = cursor.fetchone()
        return result[0] if result else None
    except Exception as e:
        print(f"Error fetching GR. No. for {consignment_number} from {table_name}: {e}")
        return None
    finally:
        if 'cursor' in locals() and cursor:  # Ensure cursor is closed
            cursor.close()


# create log file
#sys.exit()

def clean_text(input_text,IS_DOCET_NUMBER):
    """
    Cleans the input text by removing specified patterns including city-specific 
    addresses, phone lines, emails, CONSIGNOR/CONSIGNEE details, ISO lines, 
    and other unwanted text.
    """
    # List of unwanted words/phrases to remove
    
    to_be_removed = [
        "Meerut-*", "GHAZIABAD-*", "AGRA-*", "MUZAFFARNAGAR-*", "DEHRADUN0-*", "DEHRADUN-*", "MATHURA-*", "BALOTRA-*",
        "ALIGARH-*", "PILKHUWA-*", "PANIPA-*", "FARIDABAD-*", "SANJAY GANDHI TPT NAGAR-*","Shamli-*",
        "Agra", "Aligarh", "Baghpat", "Baraut", "Bareilly", "Bulandshahar", "Dehradun", "Deoband", "Etah",
        "Farrukhabad", "Firozabad", "Ghaziabad", "Hapur", "Haridwar", "Hathras", "Itawa", "Jhansi", "Jawalapur",
        "Kairana", "Kandhla", "Kasganj", "Khatauli", "Khurja", "Kosi-Kalan", "Lalitpur", "Mainpuri", "Mathura",
        "Mawana", "Meerut", "Modinagar", "Moradabad", "Mussoorie", "Muzaffamagar", "Noida", "Pilkhuwa", "Rampur",
        "Rishikesh", "Roorkee", "Saharanpur", "ardhana", "Shamli", "Shikohabad", "Sikandrabad", "Sikandra-u",
        "Sirsaganj", "Tundia", "Vikasnagar", "No. of Pkgs.", "TERMS & CONDITION", "TERMS & CONDITIONS",
        "TERMS AND CONDITIONS", "TERMS AND CONDITION", "PRINTED OVERLEAF", "Brop", "Fleam", "Rio Powood",
        "Consignee Copy", "DRIVER COPY", "NOTICE", "The consignment covered by this", "receipt from shall be stored",
        "control of the transport operator", "delivered to or", "to the order of the consignees",
        "It shall under no circumstances", "to any one without the written authority", "consignee, bank or its order","STOP24047719","Fleet Owners & Transport Contractors","Fleet Owners","Transport Contractors","&","& Transport Contractors","що",
        "endorsed on the consignee's copy", "or on a separate letter of authority","Rishikash", "Rishikesh","Sardhana",",Sardhana",",","•Relay Best werk","Retail Sove","8) Вгор",
        "Sardhana", "Shami", "Sikandra-rau", "Tundla","GRB",
        "D-47, Sector-22, Industrial Area, Road, Near Bhatta No-5, (U.P.) -201 003, India",
        "D-47", "Sector-22", "Industrial Area", "Road", "Near Bhatta No-5", "(U.P.)", "India",
        "PACKAGE INFORMATION", "NO. OF", "PKGS.", "TYPE OF", "PACKING", "SAID TO CONTAIN", "SAD",
        "(U.P.)", "E:", "Website:", "PKGS.", "TO","201 003","003","Nagina","licable",": :","Consignor M/s.","d by:",'.',"سد","ST0924051289","ST0924051227",
        "F-118", "Free Ganj", "AT OWNER'S RISK","INSURANCE","224118, 9286876252","9719994789","9917782598","The customer has stated that:","9897263226","9910485151","9319518025","He has nor insured the consignment","OR",
        "He has insured the consignment","Company:","9634636161","9760015347","Policy No.:","Amount","8534916541, 8439230001",
        "9560501563, 9911864317",'hasra No.-233 Vill-Mo',"sto ' Vill-Mo","CARTON MEDICINE","09910485151","9350040541","DRSH","COURT","mojte","set of special lorry receipt form shall be stored at the","destination under the and shall be the","CONSIGNOR MISHARAMPAL SATYAPAL","( Pkgs.",
        "no-339FA","8923300601935822246","892330060","1935822246","GSTIN-09AADCL0646F1ZO","09AADCL0646F1ZO","24253451600973","Act 2007","Carriage By Act 2007","Registration No. UP-14-07-2016-0078","UP-14-07-2016-0078","Sikandra-", "rau","04 Can","JOWAR RS-086 ()","260124007174" 
    ]

    # Regex patterns for specific unwanted text
    patterns = {
        "address": r"(H\. O\.|B\. O\.).*",
        "address2": r"(H\.O\.:.*?)(\n|$)|B\.O\.:.*?(\n|$)|H\.O::.*?(\n|$)|B\.O::.*?(\n|$)",  # H.O. and B.O. variations
        "phone": r"(Phone No\.?:|Mob\.?:).*?(\n|$)",  # Matches phone variations
        "consignor": r"(CONSIGNOR MS|CONSIGNOR M/S).*?(\n|$)",  # Matches CONSIGNOR MS or M/S
        "consignee": r"(CONSIGNEE M/S).*?(\n|$)",  # Matches CONSIGNEE M/S
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",  # Matches emails
        "gstin": r"GSTIN:.*?(\n|$)",  # Matches GSTIN lines
        "iso": r"ISO.*?(\n|$)",  # Matches ISO lines
        "mob_variations": r"Mob\s*:?.*?(\n|$)",  # Matches 'Mob' variations
        "ph_variations": r"Ph\s*:?.*?(\n|$)",  # Matches 'Ph' variations
        "plus91": r"\+91-?\s*\d+.*?(\n|$)",  # Matches phone numbers starting with +91,
        "description": r"DESCRIPTION\s*[:\-]?\s*(.*?)(\n|$)",  # Matches "DESCRIPTION" followed by text until newline
        "rio_powood": r"Rio Powood\s*[:\-]?\s*(.*?)(\n|$)",
        "Nove": r"Nove\s*[:\-]?\s*(.*?)(\n|$)",
        "invoice": r"INVOICE\s*[:\-]?\s*(\d+)",  # Matches "INVOICE" followed by a number
        "bill_no": r"BILL\s*NO\s*[:\-]?\s*(\d+)",  # Matches "BILL NO" followed by a number
        "ho_bo": r".*?(H\s*\.?\s*O\.?|B\s*\.?\s*O\.?).*?(\n|$)",  # Matches H.O. or B.O. variations
        "email2": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",  # Matches emails
        "website": r"\b(?:https?://)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?\b",  # Matches URLs
        "bo": r"B\.?\s*O\.?\s*:?.*?(\n|$)",  # Matches B.O. variations
        "head_office": r"Head\s*Office\s*:.*?(\n|$)",  # Matches "Head Office:" followed by any text until newline
    }

    # Apply regex patterns to clean specific unwanted text
    for name, pattern in patterns.items():
        input_text = re.sub(pattern, "", input_text, flags=re.IGNORECASE)
    
    cleaned_text = input_text
    # Remove city and phrase patterns from `to_be_removed`
    for item in to_be_removed:
        # Handle patterns with wildcards
        if "-" in item:
            pattern = rf"\b{re.escape(item.split('-')[0])}-\S+\b"
        else:
            pattern = rf"\b{re.escape(item)}\b"
        cleaned_text = re.sub(pattern, "", cleaned_text, flags=re.IGNORECASE)

    # if IS_DOCET_NUMBER then remove every digit less than  32892
     # Check if IS_DOCET_NUMBER is True
    if IS_DOCET_NUMBER:
        # Use regex to remove numbers less than 32892
        # Explanation:
        # \b - Ensures we match whole numbers
        # (\d+) - Captures any numeric value
        # A lambda function checks the value and retains only those >= 32892
        cleaned_text = re.sub(
            r'\b\d+\b',
            lambda match: match.group(0) if int(match.group(0)) >= 32892 else '',
            cleaned_text
        )
        # Remove any extra spaces caused by replacements
        cleaned_text = re.sub(r'\s{2,}', ' ', cleaned_text).strip()




    # Apply regex patterns to remove matching lines
   
    """ for name, pattern in patterns.items():
        cleaned_text = re.sub(pattern, "", cleaned_text, flags=re.IGNORECASE) """

   
    # Replace broken words
    replacements = { 
        r"\bCKET\b": "DOCKET",  # Replace 'CKET' with 'DOCKET'
        r"\bGRN:\b": "GRN.",  # Replace 'CKET' with 'DOCKET' Goods Receipt -
        r"Goods Receipt\s*-\s*": "GRN. ",    # Replace 'Goods Receipt -' with 'GRN.'
        r"\bZVS-\b": "ZYS-",  # Replace 'ZVS' with 'ZYS'
    }

    # Apply replacements for broken words
    for broken_word, replacement in replacements.items():
        cleaned_text = re.sub(broken_word, replacement, cleaned_text, flags=re.IGNORECASE)

    # Normalize spaces and newlines
    cleaned_text = re.sub(r"\s{2,}", " ", cleaned_text)  # Replace multiple spaces with one
    cleaned_text = re.sub(r"\n{2,}", "\n", cleaned_text)  # Replace multiple newlines with one

    return cleaned_text.strip()
def clean_dates_from_text(text):
    """
    Removes dates in the formats dd-mm-yyyy or dd/mm/yyyy from the given text.
    
    :param text: The input string to clean.
    :return: The cleaned text with dates removed.
    """
    # Define regex for dates (dd-mm-yyyy or dd/mm/yyyy)
    date_pattern = r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b"
    
    # Replace all matched dates with an empty string
    cleaned_text = re.sub(date_pattern, "", text)
    
    # Normalize extra spaces left behind after removal
    cleaned_text = re.sub(r"\s{2,}", " ", cleaned_text).strip()
    
    return cleaned_text
def fetch_number_near_gr_no(text):
    """
    Extracts the 4-9 digit number closest to 'GR. No.' in the text.
    Considers both preceding and succeeding numbers.
    """
    # Updated regex to capture numbers before and after 'GR. No.'
    pattern = r"(?:\b(\d{4,9})\b).*?GR\.?\s*No\.?|GR\.?\s*No\.?.*?\b(\d{4,9})\b"
    
    # Debugging text structure
    #print("Debugging Text Structure:")
    #print(repr(text))

    # Search for the pattern
    matches = re.findall(pattern, text, re.IGNORECASE | re.DOTALL)
    
    # Debugging matches
    #print("Matches Found:", matches)
    
    # Flatten matches and remove empty entries
    numbers = [num for match in matches for num in match if num]
    
    # Return the first number closest to 'GR. No.'
    if numbers:
        #print("Filtered Numbers:", numbers)
        return numbers[0]
    
    #print("No match found.")
    return None
# Function to remove prefixes or suffixes
def remove_prefix_suffix(consignment_number):
     # REMOVE PREFIXES OR SUFFIXES
    TO_REMOVE = [
        "CONSIGNMENT NOTE",
        "CONSIGNMENT",
        "NOTE",
        "DOCKET NUMBER",
        "DOCKET",
        "NUMBER",
        "DEEN",
        "DEEN.",
        "Doon",
        "GRN",
        "GRM",
        "GRN.",
        "NO",
        "NO.",
        "NO-",
        "DATED",
        "DATE",
        "EWB. No.",
        "EWB No.",
        "EWB",
        "G.R. No.",
        "G.R.",
        "G.R",
        "GRN.",
        "GRN",
        "GR",
        "No.",
        "No",
        "No-",
        "GRIN",
    ]
    for prefix in TO_REMOVE:
        consignment_number = consignment_number.replace(prefix, "", 1).strip()
    return consignment_number

def clean_consignment_number(consignment_number):
    """
    Extracts only the numeric part of the consignment number, removing any non-numeric text.
    
    :param consignment_number: The input consignment number as a string.
    :return: The cleaned numeric part of the consignment number.
    """
   
    # Remove prefixes or suffixes
    consignment_number = remove_prefix_suffix(consignment_number)

    # Use regex to extract only the numeric part (6 to 12 digits)
    match = re.search(r"\b\d{3,9}\b", consignment_number)
    return match.group(0) if match else None


def fetch_company_name(text):
    """
    Searches for specific company names in the provided text and returns the matched name.
    
    :param text: The input text to search in.
    :return: The matched company name if found; otherwise, None.
    """
    if text is None:
        return None
    # Define company patterns with their return values
    company_patterns = {
        r"\bjagdamba[\w\W]*\b": "jagdamba",  # Matches 'jagdamba' with any trailing special characters
        r"\bjagdambad[\w\W]*\b": "jagdamba",
        r"\bJAGDANAA[\w\W]*\b": "jagdamba",  # Matches 'jagdamba' with any trailing special characters
        r"\bvikram[\w\W]*\b": "jagdamba",  # Maps 'vikram' to 'jagdamba'
        r"\bvikramd[\w\W]*\b": "jagdamba",  # Maps 'vikram' to 'jagdamba'
        r"\bjag[\w\W]*\b": "jag",
        r"\bjagd[\w\W]*\b": "jag",
        r"\bwings[\w\W]*\b": "jag",
        r"\bwingsd[\w\W]*\b": "jag",

        
    }

    # Normalize text to lowercase for case-insensitive matching
    text = text.lower()

    # Loop through patterns and search for matches
    for pattern, return_value in company_patterns.items():
        #print(f"Pattern: {pattern}")
        if re.search(pattern, text, re.IGNORECASE):
            #print(f"Matched: {return_value}")
            return return_value

    # If no match is found, return None
    return None
def isSeparateThisImage(text):
    """
    Searches for specific transport names in the provided text and handles trailing spaces or special characters.
    
    :param text: The input text to search in.
    :return: The matched transport name if found; otherwise, None.
    """
    # Debug: Check if text is None
    if text is None:
        print("Debug: Input text is None.")
        return None
    
    # Define transport patterns with their return values
    transport_patterns = {
        r"\bsanjeev golden[\s\W]*": "SANJEEV GOLDEN",  # Matches "SANJEEV GOLDEN" with potential trailing characters
        r"\bbareilly chandausi[\s\W]*": "BAREILLY CHANDOSI",  # Matches "BAREILLY CHANDOSI"
        r"\blucknow bareilly[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blucknow bareilly[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blucknow beilly[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blucknow bargely[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blucknow reilly[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blbtc[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\bjai durga[\s\W]*": "JAI DURGA",  # Matches "JAI DURGA"
        r"\bagarwal transport[\s\W]*": "AGGARWAL TRANSPORT",  # Matches "AGGARWAL TRANSPORT"
        r"\bambey transport[\s\W]*": "AMBEY TRANSPORT",  # Matches "AMBEY TRANSPORT"
        r"\bgarg goods[\s\W]*": "GARG GOODS",  # Matches "GARG GOODS"
        r"\bkuljeet transport[\s\W]*": "KULJEET TRANSPORT",  # Matches "KULJEET TRANSPORT"
        r"\bjagdish transport[\s\W]*": "JAGDISH TRANSPORT",  # Matches "JAGDISH TRANSPORT"
        r"\bshree durga[\s\W]*": "SHREE DURGA",  # Matches "SHREE DURGA"
        r"\bshri siddhi[\s\W]*": "SHRI SIDDHI",  # Matches "SHRI SIDDHI"
        r"\bshri\s*siddhi(?:\s*vinayak)?\s*roadline[\s\W]*": "SHRI SIDDHI VINAYAK",  # Matches "Shri Siddhi Vinayak Roadline"
        r"\bashoka\s*transport[\s\W]*": "ASHOKA TRANSPORT",  # Matches "Ashoka Transport"
        r"\bdtca[\s\W]*": "DTCA",  # Matches "DTCA"
        r"\bkapil malik[\s\W]*": "KAPIL MALIK GOODS TRANSPORT",  # Matches "kapil malik"
        r"\bswikriti transport[\s\W]*": "SWIKRITI TRANSPORT",  # Matches "WIKRITI TRANSPORT"
        r"\bdavesh freight[\s\W]*": "DAVESHA FREIGHT CRARRIER",  # Matches "WIKRITI TRANSPORT"
        r"\bshubham transport[\s\W]*": "SHUBHAM TRANSPORT",  # Matches "SHUBHAM TRANSPORT"
        r"\bradhika transport[\s\W]*": "SHUBHAM TRANSPORT",  # Matches "SHUBHAM TRANSPORT"
    }
    # Normalize the input text to lowercase for case-insensitive matching
    text = text.lower()
    #print(f"Debug: Input text normalized to lowercase:\n{text}")
    
    # Loop through each pattern and check for matches in the text
    for pattern, return_value in transport_patterns.items():
        #print(f"Debug: Checking pattern: {pattern}")
        if re.search(pattern, text):
            #print(f"Debug: Match found for pattern: {pattern}")
            #print(f"Debug: Matched Transport Name: {return_value}")
            return return_value

    # If no patterns match
    #print("Debug: No matches found.")
    return None

    
def fetch_single_date_and_validate(text):
    """
    Fetches the first valid date around 'DATED' or 'TIME', validates, and corrects it.
    If multiple dates are found, attempts to return the most accurate one.
    """
    # Regex patterns for dates around keywords
    date_patterns = [
        # Matches "DATED" followed by a date
        r"DATED\s*[:\-]?\s*(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})",
        # Matches "DATE" followed by a date
        r"DATE\s*[:\-]?\s*(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})",
        # Matches date directly above "TIME"
        r"(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})\s*\n\s*TIME",
        # Matches date on the next line after "DATED"
        r"DATED\s*[:\-]?\s*\n\s*(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})",
        # Matches date on the next line after "DATE"
        r"DATE\s*[:\-]?\s*\n\s*(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})",
        # Fallback: Matches any date-like string anywhere in the document
        r"(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})"
    ]

    DATES = []  # To store all matched and validated dates
    for date_pattern in date_patterns:
        matches = re.finditer(date_pattern, text, re.IGNORECASE | re.DOTALL)
        for match in matches:
            raw_date = match.group(1)
            if raw_date:  # Only add if valid
                #print(f"Matched and validated date: {raw_date}")
                DATES.append(raw_date)

    # If multiple dates are found, select the best date
    
    DATES = list(set(DATES))
    #print(f"Found dates: {DATES}")
    if len(DATES) > 1:
        # Filter dates with a valid full year >= 2021
        valid_full_year_dates = [
            d for d in DATES if len(d.split("/")[-1]) == 4 and datetime.strptime(d, "%d/%m/%Y").year >= 2021
        ]
        if valid_full_year_dates:
            # Sort the full-year valid dates
            sorted_dates = sorted(valid_full_year_dates, key=lambda d: datetime.strptime(d, "%d/%m/%Y"))
            date = validate_and_assign_date(sorted_dates[0])
            # spilit cant be - or /

            if int(year) < 2021:
                date = validate_and_assign_date(DATES[0])
            return date
        else:
            #print("DATES[0] ", DATES[0])
            date = validate_and_assign_date(DATES[0]);
            year = date.split("/")[-1]
            if int(year) < 2021:
                date = validate_and_assign_date(DATES[1])
            return date

            

    
    # If only one date is found, return it
    if len(DATES) == 1:
        #print(f"Single date found: {DATES[0]}")
        return validate_and_assign_date(DATES[0])

    # If no dates are found, return None
    else:
        #print("No valid dates found.")
        return None


def validate_and_assign_date(date_str):
    """
    Validates and corrects a date string to the closest possible valid date.
    Handles both 'dd-mm-yyyy' and 'dd/mm/yyyy' formats.
    If invalid, assigns `31/01/YYYY`.
    :param date_str: The detected date string.
    :return: A valid date string in "DD/MM/YYYY" format or None if invalid.
    """
    try:
        # Replace "-" with "/" to normalize the format
        date_str = date_str.replace("-", "/")

        # Split the detected date into components
        components = re.split(r"[\/\-]", date_str)
        if len(components) != 3:
            return None  # Invalid format
        
        # Extract day, month, and year components
        day, month, year = components
        
        # Handle day
        if len(day) > 2 or int(day) > 31:
            day = 31
        else:
            day = int(day)

        # Handle month
        if len(month) > 2 or int(month) > 12:
            month = 1
        else:
            month = int(month)

        # Handle year
        year = int(year)
        #print(f"Year: {year}")
        if year < 100:  # Handle two-digit years
            year += 2000 
    
        #print(f"Corrected Date {date_str}: {day}/{month}/{year}")
        # Validate and return the date
        try:
            corrected_date = datetime(year, month, day)
        except ValueError:
            # Assign to 31/01/YYYY if invalid
            corrected_date = datetime(year, 1, 31)

        # Return the corrected date in DD/MM/YYYY format
        return corrected_date.strftime("%d/%m/%Y")
    except Exception as e:
        print(f"Error validating date {date_str}: {e}")
        return None


# Set up Google Vision API client
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "./client_secret_288127297142-8v4qgubcp78rol322tjlvrjdpfhevruo.apps.googleusercontent.com.json"  # Update with your JSON key path
client = vision.ImageAnnotatorClient()
# get fincail year based on date
from datetime import datetime

def get_financial_year(date):
    """
    Determines the financial year based on the given date.
    Financial year starts on April 1 and ends on March 31.
    
    :param date: Date string in the format "DD-MM-YYYY" or "DD/MM/YYYY"
    :return: A string representing the financial year, e.g., "2023-2024"
    """
    # Handle both "-" and "/" as separators
    date = date.replace("/", "-")
    
    # Parse the date
    parsed_date = datetime.strptime(date, "%d-%m-%Y")
    
    # Extract year, month
    year = parsed_date.year
    month = parsed_date.month
    
    # Determine financial year
    if month >= 4:  # From April to December
        start_year = year
        end_year = year + 1
    else:  # From January to March
        start_year = year - 1
        end_year = year
    
    return f"{start_year}-{end_year}"

# Test the function
#print(get_financial_year("15-05-2023"))  # Output: "2023-2024"
#print(get_financial_year("31/03/2023"))  # Output: "2022-2023"

# Function to extract number after keywords
def extract_delayed_number(text, keywords):
    lines = text.splitlines()  # Split text into lines
    for keyword in keywords:
        for i, line in enumerate(lines): 
            if re.search(keyword, line, re.IGNORECASE):  # Match keyword
                # Check subsequent lines for numbers
                for j in range(i + 1, len(lines)):
                    match = re.search(r"\b\d+\b", lines[j])  # Match standalone number
                    if match:
                        return match.group(0)  # Return the first matched number
    return None

def extract_and_highlight_text(image_path):
    try:
        # Load the image
        with open(image_path, 'rb') as image_file:
            content = image_file.read()

        image = vision.Image(content=content)
        response = client.text_detection(image=image)

        # Parse text detection response
        if response.error.message:
            raise Exception(f"Google Vision API error: {response.error.message}")

        annotations = response.text_annotations
        if not annotations:
            print(f"No text found in {image_path}")
            return None, None, None, None, None , None

        # Full extracted text
        extracted_text = annotations[0].description
        #print(f"Extracted Text UNCLEN: {extracted_text}")
         # Check if DOCKET NUMBER is in the extracted text and consignment_number is None or invalid
        IS_DOCET_NUMBER = False
        if re.search(r"DOCKET\s*NUMBER", extracted_text, re.IGNORECASE):
         IS_DOCET_NUMBER = True
         
        company_name = fetch_company_name(extracted_text)
        isSeparateImage = isSeparateThisImage(extracted_text)
        #print(f"isSeparateImage : {isSeparateImage}")
        #sys.exit()
        #print("company_name " + company_name)
        #sys.exit()
        extracted_text = clean_text(extracted_text,IS_DOCET_NUMBER)
                #print(f"Consignment Number CAT 2: {consignment_number}")
        CONSIGNMENT_DATE = None
        # Fetch the date
        try:
            date_found = fetch_single_date_and_validate(extracted_text)
            if date_found:
             #print(f"Matched Date: {date_found}")
             CONSIGNMENT_DATE = date_found
            else:
             pass
        except Exception as e:
            pass

        extracted_text = clean_dates_from_text(extracted_text)
        print(f"Extracted Text: {extracted_text}")
        
        # Search for consignment numbers
        consignment_number = None
        IS_GRN = None
       
        primary_patterns = [
            r"PLK-\d+",
            r"PNP-\d+",
            r"SGN-\d+",
            r"MTH-\d+",
            r"GZB-\d+",
            r"ALG-\d+",
            r"FBD-\d+",
            r"AGR-\d+",
            r"PNP-\d+",
            r"MZN-\d+",
            r"BLT-\d+",
            r"DDN-\d+",
            r"NDA-\d+",
            r"ZYS-\d+",
            r"DRL-\d+",
            r"PNP-\d+",
            r"PLK-\s*\d+",
            r"ZYS-\s*\d+",
            r"PNP-\s*\d+",
            r"SGN-\s*\d+",
            r"MTH-\s*\d+",
            r"GZB-\s*\d+",
            r"ALG-\s*\d+",
            r"FBD-\s*\d+",
            r"AGR-\s*\d+",
            r"PNP-\s*\d+",
            r"MZN-\s*\d+",
            r"BLT-\s*\d+",
            r"DDN-\s*\d+",
            r"ZYS-\s*\d+",
            r"NDA-\s*\d+",
            r"DRL-\s*\d+",
            r"PNP-\s*\d+",

            
            r"DDR-\d+",
            r"DDR-\s*\d+",
            r"PLK-\d+",
            r"PLK-\s*\d+",
            r"PNP-\d+",
            r"PNP-\s*\d+",
            r"SGN-\d+",
            r"SGN-\s*\d+",
            r"MTH-\d+",
            r"MTH-\s*\d+",
            r"GZB-\d+",
            r"GZB-\s*\d+",
            r"ALG-\d+",
            r"ALG-\s*\d+",
            r"FBD-\d+",
            r"FBD-\s*\d+",
            r"AGR-\d+",
            r"AGR-\s*\d+",
            r"MZN-\d+",
            r"MZN-\s*\d+",
            r"BLT-\d+",
            r"BLT-\s*\d+",
            r"DDN-\d+",
            r"DDN-\s*\d+",
            r"NDA-\d+",
            r"NDA-\s*\d+",
            r"DRL-\s*\d+",
            r"ZYS-\d+",
            r"PNP-\d+",

            r"ZYS-\s*\d+",
            
        ]
        for pattern in primary_patterns:
            match = re.search(pattern, extracted_text, re.IGNORECASE)
            if match:
                consignment_number = match.group(0)
                if '-' in consignment_number:
                    second_part = consignment_number.split('-')[-1]
                    if len(second_part) < 3:
                        consignment_number = None
                    else:
                        first_part = consignment_number.split('-')[0]
                        consignment_number = f"{first_part}-{second_part.strip()}"
                #elif numarib
                elif not consignment_number.isdigit():
                    consignment_number = None
                break
        

        # Search for consignment numbers using regex if consignment_number is None
        if not consignment_number:
            # EXCLUDED LIST: Words to exclude if matched
            EXCLUDED_LIST = ['NO', 'NUMBER', 'NO.', 'ied]', 'NO', 'NE.', 'Ne', 'No', 'Te', 'NOTICE', 'JAG', 'GSTIN', 'the', 'of', 'and', 'DATED','EWB. No.']

            
            # Patterns
            # Patterns to search for
            patterns = [
                r"CONSIGNMENT NOTE\s*\n\s*(\d{3,9})", # Matches
                r"CONSIGNMENT\s*NOTE\s*[:\-]?\s*(\d+)",  # Matches "CONSIGNMENT NOTE" optionally followed by ':' or '-' and then a number
                r"CONSIGNMENT\s*NOTE\s*No\.?\s*(\d+)",
                r"DOCKET NUMBER\s*\n\s*(\d{5})",
                r"DOCKET\s*NUMBER\s*[:\-]?\s*(\d{5}+)",  # Matches "DOCKET NUMBER" optionally followed by ':' or '-' and then a number
                r"DOCKET\s*NUMBER\s*[:\-]?\s*(\d{5}+)",  # Matches "DOCKET NUMBER" optionally followed by ':' or '-' and then a number
                r"GRN.\s*[:\-]?\s*(\d+)",  # Matches "GRN" followed by a number
                r"GRN\s*[:\-]?\s*(\d+)",  # Matches "GRN" followed by a number
                r"GRIN.\s*[:\-]?\s*(\d+)",  # Matches "GRN" followed by a number
                r"GRIN\s*[:\-]?\s*(\d+)",  # Matches "GRN" followed by a number
                r"GR\. No\.:.*?\n.*?\n.*?(\d{4})", # Regex pattern to capture the 4-digit number below "GR. No.:"
                r"(\d{6,8})\s*[Gg][Rr][Nn]\.",  # Matches 6-8 digit numbers followed by "GRN." (case-insensitive)
                r"(\d{6,8})\s*[Gg][Rr][Nn]",  # Matches 6-8 digit numbers followed by "GRN" (case-insensitive)
                r"(\d{6,8})\s*[Gg][Rr]\b",    # Matches 6-8 digit numbers followed by "GR" (case-insensitive)
                r"G\.R\.\s*No\.\s*[:\-]?\s*(\d+)",  # Matches "G.R. No." followed by a number
                r"G\.R\.\s*No\.\s*(\d+)",  # Matches "G.R. No." followed by a number
                r"GR\.?\s*No\.?\s*[:\-]?\s*(?:\n\s*[A-Za-z]*)*\s*(\d{4,9})",  # Matches "GR. No." optionally followed by ':' or '-' and then a number
                r"(\d{4,9})\s*GR\.?\s*No\.?",
                r"(\d{4,9})\s*\n(?:[^\S\r\n]*[A-Za-z]+)?\s*\n\s*Date:",
                r"(\d{4,9})(?:\s*\n\s*\d{1,9})*\s*\n\s*G\.R\. No\.?:",
                r"(\d{4,9})\s*\n\s*(?:Date|DATED)",  # Matches 6-8 digit number directly above "Date" or "DATED"
                r"CONSIGNMENT NOTE(?:\s*.*?)*?\s*(\d{3,9})",  # Matches "CONSIGNMENT NOTE" followed by a number
                r"NO\.?\s*[:\-]?\s*(\d+)",
                r"(?<!EWB\.\s)GR\.?\s*NO\.?\s*[:\-]?\s*\n?\s*(\d+)",  # Multiline "GR. NO." followed by a number
                r"DATED\s*[:\-]?\s*\n\s*(\d+)",  # Matches only numbers on the next line after "DATED"
                r"DATED\s*\n\s*(\d+)",
                r"(?<!EWB\.\s)G\.R\.\s*No\.\s*:\s*Dated\s*:\s*(\d+)",
                r"(?:Date|DATED)\s*[:\-]?\s*(\d{4,9})",  # Matches "Date" or "DATED" followed by a 6-8 digit number
            
            ]

            for pattern in patterns:
                match = re.search(pattern, extracted_text, re.IGNORECASE)
                if match:
                    #print(f"Matched: {match.group(0)} {pattern} ")
                    consignment_number = match.group(0)
                    consignment_number = clean_consignment_number(consignment_number)
                    #print(f"Consignment Number: {consignment_number}")
                    # if length is less not between 6-12 then continue
                    if not consignment_number or len(consignment_number) < 3 or len(consignment_number) > 9 :
                        continue

                    
                    
                    #sys.exit()

                    # if pattern contains EWB. No. as prefix then continue
                    if re.search(r"EWB.\s*No.\s*[:\-]?\s*", consignment_number):
                        continue

                    
                    consignment_number_length = len(consignment_number)
                    # IF LENGHT IS >8 AND IS NUMBERS THEN RETURN NONE
                    if consignment_number_length > 9 and consignment_number.isdigit():
                        #print(f"Cleaned Consignment Number cat: {consignment_number}")
                        continue

                    # is IS_DOCET_NUMBER is True or company name is jag and length is > 6
                    if IS_DOCET_NUMBER and company_name == 'jag' and consignment_number_length  != 5:
                        #print(f"Cleaned Consignment Number dog: {consignment_number}")
                        continue
                    

                    # Additional numeric validation
                    try:
                        #print(f"Consignment Number CAT: {consignment_number}")
                        # cheack if it is not a date if date go to next
                        if re.search(r"\d{1,2}\/\d{1,2}\/\d{2,4}", consignment_number):
                            continue

                        # cha
                        
                        break
                    except Exception as e:
                        #print(f"Error processing consignment number: {e}")
                        consignment_number = None
        #print(f"Consignment Number: {consignment_number}")
        if not IS_DOCET_NUMBER and not consignment_number:
         consignment_number = fetch_number_near_gr_no(extracted_text)
         if not consignment_number:
            patterns = [
                r"GR\.?\s*No\.?.*?(\b\d{4,9}\b)"         # Matches numbers on the same line as "GR. No."
            ]
            # Search for the pattern in the extracted text
            for pattern in patterns:
                match = re.search(pattern, extracted_text, re.IGNORECASE | re.DOTALL)
                if match:
                    consignment_number =  match.group(1)
                    #print(f"Matched: {consignment_number} {pattern}")
                    if consignment_number:
                        break
        
        if not IS_DOCET_NUMBER and not consignment_number:
            normalized_text = re.sub(r"\s+", " ", extracted_text)
            pattern = r"(\d{4,6})(?=.*GRN\.)"
            all_matches = re.findall(pattern, normalized_text, flags=re.IGNORECASE)
            if all_matches:
                consignment_number = all_matches[-1]

        if not IS_DOCET_NUMBER and not consignment_number:
            normalized_text = re.sub(r"\s+", " ", extracted_text)
            pattern = r"GRN[:.]?\s*.*?\b(\d{4,6})\b"
            match = re.search(pattern, normalized_text, flags=re.IGNORECASE)
            if match:
                consignment_number = match.group(1)
            
             
        #print(f"Consignment Number CAT: {consignment_number}")
        if  IS_DOCET_NUMBER and ( not consignment_number or len(consignment_number) < 5 ):
                #print(f"Consignment Number CAT: {consignment_number}")
                patternSearch =  r"DOCKET NUMBER.*?\b(\d{5})\b"
                match2 = re.search(patternSearch, extracted_text, re.IGNORECASE | re.DOTALL)
                #print(f"Matched: {match2.group(0)}")
                if match2:
                    #print(f"Extracted Number CAT: {match2.group(1)}")
                    consignment_number = match2.group(1)  # Return the first matched number  
                else:
                    consignment_number = None
        #print(f"Consignment Number CAT: {consignment_number} IS_DOCET_NUMBER {IS_DOCET_NUMBER}")
        
        if IS_DOCET_NUMBER  and ( not consignment_number or  len(consignment_number) != 5):
            consignment_number = None

        #print(f"Consignment Number CAT 1: {consignment_number}")

        if (not consignment_number or len(consignment_number) < 5) and IS_DOCET_NUMBER:
            #print("DOCKET NUMBER FOUND")
            
            # Pattern to fetch the number directly above "DATE"
            patterns = [
                r"(\d+)\s*DATE",
                r"DOCKET\s*NUMBER.*?DATE.*?\b(\d{5}+)\b",
                r"DOCKET\s*NUMBER.*?\n.*?\b(\d{5})\b",
                r"(\b\d{5}\b)(?=\s*\n.*?DOCKET\s*NUMBER)"
            ]
            # Search for the pattern in the extracted text
            for pattern in patterns:
                match = re.search(pattern, extracted_text, re.IGNORECASE | re.DOTALL)
                if match:
                    consignment_number = match.group(1)
                    if len(consignment_number) != 5:
                        continue
                    #print(f"Matched: {match.group(0)}")
                    #print(f"Extracted Number: {match.group(1)}")
                    break
        

            #print(f"Error fetching date: {e}")
            #print("No valid date found.")
        #print(f"Consignment Number CAT 3: {consignment_number}")
        # trim consignment number
        if consignment_number:
         consignment_number = consignment_number.strip()
        #print(f"Consignment Number CAT 3: {consignment_number}")
        #consignment_number_length = len(consignment_number)
        # IF LENGHT IS >8 AND IS NUMBERS THEN RETURN NONE
        
        
        if consignment_number and len(consignment_number) > 9 and consignment_number.isdigit():
            return None, None, CONSIGNMENT_DATE , company_name, extracted_text, isSeparateImage

        #print(f"Consignment Number CAT 4: {consignment_number}")
        if consignment_number and len(consignment_number) >= 3:
            #print(f"Consignment Number CAT: {consignment_number} {pattern}")
            # cheack from table
            #print(f"Consignment Number CAT: {consignment_number}")
            # log the consignment number
            # fetch from table
            #sys.exit()
            #print(found_db);
            
            response = (consignment_number , IS_DOCET_NUMBER , CONSIGNMENT_DATE, company_name, extracted_text,isSeparateImage)
            return  response
            
        else:
            #print("No consignment number found.")
            response = (None, IS_DOCET_NUMBER, CONSIGNMENT_DATE, company_name, extracted_text, isSeparateImage)
            return response

       

    except Exception as e:
        #print(f"Error processing {image_path}: {e}")
        return None, None, None, CONSIGNMENT_DATE, extracted_text, isSeparateImage

# Process directories in the current directory
log_file = "log.txt"
current_dir = os.getcwd()
subdirs = [os.path.join(current_dir, d) for d in os.listdir(current_dir) if os.path.isdir(os.path.join(current_dir, d))]
for subdir in subdirs:
    image_dir = os.path.join(subdir, "undetected")
    if not os.path.exists(image_dir):
        continue

    print(f"\nProcessing directory: {subdir}")
    FILE_PROCESSED = 0
    CONSIGNMENT_NUMBER_FOUND = 0
    DATE_FOUND = 0
    COMPANY_NAME_FOUND = 0

    for filename in os.listdir(image_dir):
        file_path = os.path.join(image_dir, filename)

        if os.path.isfile(file_path) and filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
            #print(f"Processing {file_path}...")
                 
            #print(f"IS DIRECT: {is_direct}")
            consignment_number, IS_DOCET_NUMBER, CONSIGNMENT_DATE, company_name, extracted_text, isSeparateImage = extract_and_highlight_text(file_path)
            """ if company_name == 'jagdamba' and CONSIGNMENT_DATE:
                is_direct = is_direct_consignment(consignment_number,CONSIGNMENT_DATE)
                #print(f"IS DIRECT: {is_direct}")
                try:
                    # Check if it is a direct consignment
                    #print(f"IS DIRECT: {is_direct}")

                    if is_direct and 'gr_no' in is_direct:
                        gr_no = is_direct['gr_no']
                        #print(f"GR NO: {gr_no}")
                        consignment_number = gr_no
                except Exception as e:
                    pass
                    #print(f"Error checking direct consignment for {consignment_number}: {e}") """
            #print("extracted_text ", extracted_text)
            #isSeparateImage = isSeparateThisImage(extracted_text)
            #log_data(image_path, consignment_number, None, CONSIGNMENT_DATE, company_name, "LOGING TEXT DATA",text=extracted_text)
            print(f"Consignment Number: {consignment_number} , IS_DOCET_NUMBER: {IS_DOCET_NUMBER} , CONSIGNMENT_DATE: {CONSIGNMENT_DATE} , COMPANY_NAME: {company_name} , filename {filename.strip()} , isSeparateImage {isSeparateImage}")
            
           
            with open(log_file, 'a') as log:
                    log.write(f"Consignment Number: {consignment_number} , IS_DOCET_NUMBER: {IS_DOCET_NUMBER} , CONSIGNMENT_DATE: {CONSIGNMENT_DATE} , COMPANY_NAME: {company_name} , filename {filename.strip()} \t isSeparateImage {isSeparateImage}\n")
                
            FILE_PROCESSED += 1
            if company_name:
                COMPANY_NAME_FOUND += 1
            if CONSIGNMENT_DATE:
                DATE_FOUND += 1
            if consignment_number:
                CONSIGNMENT_NUMBER_FOUND += 1
                image_extension = os.path.splitext(filename)[1]
                if isSeparateImage:
                  company_folder = 'SEPRATE'
                else:
                  company_folder = company_name or 'DISCARD'
                if IS_DOCET_NUMBER:
                    company_folder = 'jag'

                financial_year = ''
                try:
                    if CONSIGNMENT_DATE:
                        financial_year = get_financial_year(CONSIGNMENT_DATE)
                except Exception as e:
                    print(f"Error processing financial year: {e}")

                #new_file_path = os.path.join(company_folder, f"{consignment_number}{image_extension}")
                #os.makedirs(os.path.dirname(new_file_path), exist_ok=True)
                # log in log file
                
                try:
                    if consignment_number:
                        new_file_path = handle_file_move(
                            file_path=file_path,
                            company_folder=company_folder,
                            financial_year=financial_year,
                            consignment_number=consignment_number,
                            image_dir=image_dir
                        )
                        #is_org = fetch_gr_no_IN_ORG_from_table(consignment_number, company_name)
                        #sys.exit()
                        # Update file path in the database
                       
                        #found_db = fetch_gr_no_from_table(consignment_number,company_name)
                        #if found_db:
                            #update_file_path_in_table(company_name, is_org, consignment_number, new_file_path,CONSIGNMENT_DATE)
                        image_path = file_path;
                        # Log success
                        log_data(image_path, consignment_number, new_file_path, CONSIGNMENT_DATE, company_name, "File moved successfully",text=extracted_text)
                    else:
                        new_file_path = ''
                        if(isSeparateImage):
                            # move file to SEPRATE folder
                            new_file_path = handle_file_move(
                                file_path=file_path,
                                company_folder='SEPRATE',
                                financial_year=financial_year,
                                consignment_number=filename,
                                image_dir=image_dir
                            )
                        # Log failure to move
                        #log_data(image_path, consignment_number, None, CONSIGNMENT_DATE, company_name, "File move failed or already exists",text=extracted_text)
                except Exception as e:
                    print(f"Error processing file {file_path}: {e}")
            else:
                financial_year = ''
                try:
                    if CONSIGNMENT_DATE:
                        financial_year = get_financial_year(CONSIGNMENT_DATE)
                except Exception as e:
                    print(f"Error processing financial year: {e}")
                if(isSeparateImage):
                    # move file to SEPRATE folder
                    new_file_path = handle_file_move(
                        file_path=file_path,
                        company_folder='SEPRATE',
                        financial_year=financial_year,
                        consignment_number=filename,
                        image_dir=image_dir
                    )
                    # Log failure to move
                    #log_data(file_path, consignment_number, None, CONSIGNMENT_DATE, company_name, "File move Seprated",text=extracted_text)
            

print("\nSummary:")
print(f"Total Files Processed: {FILE_PROCESSED}")
print(f"Consignment Numbers Found: {CONSIGNMENT_NUMBER_FOUND}")
print(f"Dates Found: {DATE_FOUND}")
print(f"Company Names Found: {COMPANY_NAME_FOUND}")

 