import re

def clean_text(input_text, IS_DOCET_NUMBER):
    """
    Cleans the input text by removing numbers less than 32892 if IS_DOCET_NUMBER is True.
    """
    # Check if IS_DOCET_NUMBER is True
    if IS_DOCET_NUMBER:
        # Use regex to remove numbers less than 32892
        # Explanation:
        # \b - Ensures we match whole numbers
        # (\d+) - Captures any numeric value
        # A lambda function checks the value and retains only those >= 32892
        input_text = re.sub(
            r'\b\d+\b',
            lambda match: match.group(0) if int(match.group(0)) >= 32892 else '',
            input_text
        )
        # Remove any extra spaces caused by replacements
        input_text = re.sub(r'\s{2,}', ' ', input_text).strip()

    return input_text

# Test case
text = """
GR. No.:
Dated:
8031
03/06/2024 09:03:47PM
32892
DELIVERY AT
12345
Jagdamba Transport Carriers Pvt Consignor's:
9999
"""

# Run the function
result = clean_text(text, IS_DOCET_NUMBER=True)
print("Cleaned Text:\n", result)
