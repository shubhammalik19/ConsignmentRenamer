import re

def clean_text_for_invoice(input_text, isSeparateImage):
    """
    Cleans the input text by removing unwanted prefixes or numbers that appear
    after `Invoice` or `Invoice:` keywords.
    """
    # Define patterns to clean unwanted prefixes or numbers after Invoice keywords
    patterns = [
        r"000\s*nvoice\b",                # Matches `000nvoice`
        r"000 Invoice\b",                 # Matches `000 Invoice`
        r"\.nvoice\b",                    # Matches `.nvoice`
        r"000\s*nvoice\s*:\s*\d+",        # Matches `000 Invoice: number`
        r"(^\d{1,4})\s*\n\s*Invoice:",    # Matches standalone numbers on the previous line with `Invoice:`
        r"(^\d+)\s+Invoice:",             # Matches numbers directly before `Invoice:`
        r"(Invoice:+)\s*\d+",             # Matches `Invoice:::` or `Invoice::` followed by digits
        r"(Invoice)\s*\n\s*(\d{7,})",     # Matches large numbers (7+ digits) directly after `Invoice`
        r"(Invoice:)\s*\d+",              # Matches `Invoice:` followed by digits
    ]

    # Apply each pattern to clean the text
    for pattern in patterns:
        input_text = re.sub(pattern, "Invoice:", input_text, flags=re.IGNORECASE | re.MULTILINE)

    return input_text

# Example usage
extracted_text = """
RANCHES AND AGENCIES: MUZAFFARNAGAR MURADNAGAR BULANDSHAHR DELHI
Head
: B-86, TRANSPORT NAGAR, -247001 RISK
CE The c
μ
Invoice
3319518020 Ame Value:
Date:
Risk:
Invoice: GR. No.:
Dated:
2569
"""

cleaned_text = clean_text_for_invoice(extracted_text, 'VTC')
print(cleaned_text)
