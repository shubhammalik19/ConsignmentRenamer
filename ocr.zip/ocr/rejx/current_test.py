import re

def clean_dates_from_text(text):
    """
    Removes dates in the formats dd-mm-yyyy or dd/mm/yyyy from the given text.
    
    :param text: The input string to clean.
    :return: The cleaned text with dates removed.
    """
    # Define regex for dates (dd-mm-yyyy or dd/mm/yyyy)
    date_pattern = r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b"
    
    # Replace all matched dates with an empty string
    cleaned_text = re.sub(date_pattern, "", text)
    
    # Normalize extra spaces left behind after removal
    cleaned_text = re.sub(r"\s{2,}", " ", cleaned_text).strip()
    
    return cleaned_text

# Example usage
sample_text = """
This document was created on 10-01-2024.
The next review is scheduled for 15/02/2025.
Invalid dates like 32-13-2024 or 29/02/2023 are ignored.
"""

cleaned_text = clean_dates_from_text(sample_text)
print(cleaned_text)
