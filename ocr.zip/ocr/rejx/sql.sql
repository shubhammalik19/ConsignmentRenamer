SELECT
    DISTINCT `acc`,
    `accounts`.`acc_name`,
    SUM(`dr_amt`) AS `dr_amt`,
    SUM(`cr_amt`) AS `cr_amt`,
    (`accounts`.`op_bal` - `accounts`.`op_bal_cr`) AS `op_bal`,
    GROUP_CONCAT(`bill_no`) AS `bill_nos`,
    GROUP_CONCAT(`pod_no`) AS `pod_nos`
FROM
    (
        SELECT
            'Bill' AS `type`,
            `party` AS `acc`,
            `net_amt` AS `dr_amt`,
            0 `cr_amt`,
            bill_no,
            '' pod_no
        FROM
            `bill`
        WHERE
            `bill_date` BETWEEN '2024-02-01'
            AND '2025-01-10'
            AND `company_name` = 'DHAN LAXMI LOGISTIC'
            AND `net_amt` > 0
            AND br_code = '100'
        UNION
        ALL
        SELECT
            'POD' AS `type`,
            `pon_ac` AS `acc`,
            `net_bal` `dr_amt`,
            0 AS `cr_amt`,
            '' bill_no,
            `pod_no`
        FROM
            `pod`
        WHERE
            `pod_date` BETWEEN '2024-02-01'
            AND '2025-01-10'
            AND `company_name` = 'DHAN LAXMI LOGISTIC'
            AND `pod`.`bill_status` = 'Unbilled'
            AND `net_bal` > 0
            AND br_code = '100'
        UNION
        ALL
        SELECT
            'POD' AS `type`,
            `pon_ac` AS `acc`,
            0 `dr_amt`,
            `receipt` AS `cr_amt`,
            '' bill_no,
            `pod_no`
        FROM
            `pod`
        WHERE
            `pod_date` BETWEEN '2024-02-01'
            AND '2025-01-10'
            AND `company_name` = 'DHAN LAXMI LOGISTIC'
            AND `pod`.`bill_status` = 'Unbilled'
            AND `receipt` > 0
            AND br_code = '100'
        UNION
        ALL
        SELECT
            'Receipt' AS `type`,
            `paid_to` AS `acc`,
            0 AS dr_amt,
            amount AS cr_amt,
            voucher_no AS bill_no,
            '' pod_no
        FROM
            voucher
        WHERE
            v_type = 'Receipt'
            AND voucher_dt BETWEEN '2024-02-01'
            AND '2025-01-10'
            AND company_name = 'DHAN LAXMI LOGISTIC'
            AND br_cd = '100'
        UNION
        ALL
        SELECT
            'Contra' AS `type`,
            `to_ac` AS `acc`,
            0 dr_amt,
            `cr_amt`,
            voucher_no bill_no,
            '' pod_no
        FROM
            voucher_contra
        WHERE
            voucher_dt BETWEEN '2024-02-01'
            AND '2025-01-10'
            AND company_name = 'DHAN LAXMI LOGISTIC'
            AND br_cd = '100'
    ) AS `cat`
    INNER JOIN `accounts` ON `cat`.`acc` = `accounts`.`acc_id`
WHERE
    `company_name` = 'DHAN LAXMI LOGISTIC'
    AND `accounts`.`acc_name` != ''
GROUP BY
    `acc`