import re

def replace_grno_with_grn0(text):
    """
    Replaces occurrences of GRNO with GRN0 in the given text.

    Args:
        text (str): The input text to process.

    Returns:
        str: The text with replacements applied.
    """
    # Regex pattern to match GRNO
    pattern = r"\\bGRNO\\b"

    # Replacement to format as GRN0
    replacement = "GRN0"

    # Apply the replacement
    text = re.sub(r"GRNO", "GRN0", text)

    return text

text = """
he consignment covered by this set of special lorry receipt form shall be stored at the GRNO 3834
destination under the control of the transport operator and shall be delivered to or to the
order of the consignee whose name is mentioned in the lorry receipt. It will under no
"""
print(replace_grno_with_grn0(text))