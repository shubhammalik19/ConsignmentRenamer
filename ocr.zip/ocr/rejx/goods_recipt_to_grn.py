import re

# Input Text
text = """
JAG
WINGS CARGO
Receipt No.
Date
464488
15-07-2024
"Wings Cargo"
JAG WINGS LOGISTICS PRIVATE LIMITED
, , , Near Bhatta No.-5, Uttar Pradesh - 201003
CONSIGNOR
LAZER . From PAN AACCJ6787G, GSTIN - 09AACCJ6787G1Z3
Goods Receipt - 464488
()
Email: .195ACHHEJANEAR HERO MOTORSGT ROADDADRI, GAUTAMBUDDHA NAGAR-(UP), Gautam Buddh Nagar, Uttar Pradesh -203207
CONSIGNEE
UJJWAL ENTERPRISES Date
2024-07-13
2024-07-13
Value
17260900
19085500
Details
"""

# Define replacements
replacements = {
    r"\bCKET\b": "DOCKET ",              # Replace 'CKET' with 'DOCKET'
    r"\bGRN:\b": "GRN. ",                # Replace 'GRN:' with 'GRN.'
    r"Goods Receipt\s*-\s*": "GRN. ",    # Replace 'Goods Receipt -' with 'GRN.'
}

# Apply replacements
cleaned_text = text  # Initialize cleaned_text with the original text
for broken_word, replacement in replacements.items():
    cleaned_text = re.sub(broken_word, replacement, cleaned_text, flags=re.IGNORECASE)

# Output the cleaned text
print("Cleaned Text:\n", cleaned_text)
