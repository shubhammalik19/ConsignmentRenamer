import re

def clean_text(input_text):
    """
    Cleans the input text by removing unwanted patterns, normalizing spacing,
    and replacing patterns like `GR TO` with `GRN.` and fixing `: , , : , GR`.
    """

    # Debug: Print initial text
    print("Initial Text:", input_text)

    # Replace `GR TO` or `GR` with `GRN.`
    input_text = re.sub(r"\bGR\s*TO\b", "GRN.", input_text, flags=re.IGNORECASE)
    input_text = re.sub(r"\bGR\b", "GRN.", input_text, flags=re.IGNORECASE)

    # Normalize patterns like `: , , : , GR<number>` to `: , GRN.<number>`
    input_text = re.sub(r": , , : , GR(\d+)", r": , GRN.\1", input_text)

    # Handle `G1<number>` replacements with `GRN.<number>`
    input_text = re.sub(r": , G1(\d+)(?!RN\.)", r": , GRN.\1", input_text)

    # Normalize extra spaces and newlines
    input_text = re.sub(r"\s{2,}", " ", input_text)  # Replace multiple spaces with one
    input_text = re.sub(r"\n{2,}", "\n", input_text)  # Replace multiple newlines with one

    # Debug: Print cleaned text
    print("Cleaned Text:", input_text)

    return input_text.strip()

# Test the function with your input
test_text = """
JAC DAMBA
TRANSP
T ORGANIZATION ianglene) noilgus
: , , : , GR103848
destination under the and shall be the
CONSIGNOR MIDHARAMPAL SATYAPAL
ANDIDA" Pkgs
GR TO GRN.
"""

cleaned_text = clean_text(test_text)
print("\nFinal Cleaned Text:\n", cleaned_text)
