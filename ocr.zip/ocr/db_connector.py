import mysql.connector
from mysql.connector import Error

def connect_to_database():
    """
    Connects to the MySQL database and returns the connection object.
    """
    try:
        # Establish a connection
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="12345",
            database="logisticsoftware_jagdamba_user"
        )
        
        if connection.is_connected():
            print("Successfully connected to the database")
            
            # Fetch and display MySQL server version
            db_info = connection.get_server_info()
            print(f"Server version: {db_info}")
            
            # Optional: Check the current database
            cursor = connection.cursor()
            cursor.execute("SELECT DATABASE();")
            record = cursor.fetchone()
            print(f"Connected to database: {record[0]}")
            
            return connection  # Return the connection for further use
            
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

def close_database_connection(connection):
    """
    Closes the given database connection.
    """
    if connection and connection.is_connected():
        connection.close()
        print("Database connection closed.")
