import os
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import pytesseract

# Specify the Tesseract binary path
pytesseract.pytesseract.tesseract_cmd = "/usr/bin/tesseract"


class GalleryApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.configure(bg="#2c3e50")  # Dark background
        width = self.winfo_screenwidth()
        height = self.winfo_screenheight()
        self.geometry(f"{width}x{height}")
        self.rename_folder = 'renamed'
        if not os.path.exists(self.rename_folder):
            os.mkdir(self.rename_folder)

        self.current_image_index = 0
        self.image_files = [file for file in os.listdir() if file.lower().endswith(("jpg", "jpeg", "png"))]
        if not self.image_files:
            messagebox.showerror("No Images", "No image files found in the current directory.")
            self.destroy()
            return

        # Preload the first 30 images
        self.preloaded_images = self.preload_images(limit=30)

        # Title Label
        title_label = tk.Label(self, text="Image Renamer", bg="#2c3e50", fg="#ecf0f1",
                               font=("Helvetica", 24, "bold"))
        title_label.pack(pady=20)

        # Current Image Name Label (Top Label)
        self.top_image_label = tk.Label(self, text="", bg="#2c3e50", fg="#ecf0f1", font=("Helvetica", 16, "italic"))
        self.top_image_label.pack(pady=10)

        # Image Display Canvas
        self.canvas = tk.Canvas(self, bg="#ecf0f1", width=width - 200, height=height - 300, highlightthickness=2,
                                highlightbackground="#34495e")
        self.canvas.pack(pady=20)

        # Controls Frame
        controls_frame = tk.Frame(self, bg="#2c3e50")
        controls_frame.pack()

        # Rename Entry
        self.rename_text = ttk.Entry(controls_frame, width=50, font=("Helvetica", 14))
        self.rename_text.grid(row=0, column=0, padx=10, pady=10)
        self.rename_text.insert(0, self.image_files[self.current_image_index])

        # Rename Button
        self.rename_button = tk.Button(controls_frame, text="Rename", bg="#27ae60", fg="white",
                                       font=("Helvetica", 14, "bold"), command=self.rename_image)
        self.rename_button.grid(row=0, column=1, padx=10, pady=10)

        # Auto-Rotate Button
        self.auto_rotate_button = tk.Button(controls_frame, text="Auto-Rotate", bg="#e67e22", fg="white",
                                            font=("Helvetica", 14, "bold"), command=self.auto_rotate_image)
        self.auto_rotate_button.grid(row=0, column=2, padx=10, pady=10)

        self.manual_rotate_button = tk.Button(
            controls_frame, 
            text="Manual Rotate 90°", 
            bg="#8e44ad", 
            fg="white", 
            font=("Helvetica", 14, "bold"), 
            command=self.manual_rotate_image
        )
        self.manual_rotate_button.grid(row=0, column=3, padx=10, pady=10)

        # Navigation Buttons
        nav_button_style = {"bg": "#2980b9", "fg": "white", "font": ("Helvetica", 14, "bold")}
        self.prev_button = tk.Button(controls_frame, text="<< Previous", **nav_button_style, command=self.show_prev_image)
        self.prev_button.grid(row=1, column=0, padx=10, pady=10)

        self.next_button = tk.Button(controls_frame, text="Next >>", **nav_button_style, command=self.show_next_image)
        self.next_button.grid(row=1, column=1, padx=10, pady=10)

        # Status Bar
        self.status_label = tk.Label(self, text="", bg="#34495e", fg="#ecf0f1", font=("Helvetica", 12))
        self.status_label.pack(fill=tk.X, side=tk.BOTTOM, pady=5)

        self.bind("<Left>", self.show_prev_image)
        self.bind("<Right>", self.show_next_image)
        self.rename_text.bind("<Return>", lambda x: self.rename_image())

        self.load_image()

    def preload_images(self, limit=30):
        """Preload a limited number of images."""
        preloaded = {}
        width = self.winfo_screenwidth() - 200
        height = self.winfo_screenheight() - 300

        for i, file in enumerate(self.image_files[:limit]):
            try:
                image = Image.open(file)
                image = image.resize((width, height), Image.LANCZOS)
                preloaded[file] = ImageTk.PhotoImage(image)
            except Exception as e:
                print(f"Error preloading image {file}: {e}")
        return preloaded

    def auto_rotate_image(self):
        """Automatically rotate the image based on detected text orientation."""
        try:
            image_path = self.image_files[self.current_image_index]
            image = Image.open(image_path)

            # Detect orientation using Tesseract
            config = "--psm 0"  # Automatic page segmentation with orientation detection
            osd = pytesseract.image_to_osd(image, config=config)
            orientation = int(osd.split("Orientation in degrees: ")[1].split("\n")[0])

            # Rotate the image if necessary
            if orientation != 0:
                rotated_image = image.rotate(-orientation, expand=True)
                rotated_image.save(image_path)

                # Update preloaded image
                width = self.winfo_screenwidth() - 200
                height = self.winfo_screenheight() - 300
                rotated_image = rotated_image.resize((width, height), Image.LANCZOS)
                self.preloaded_images[image_path] = ImageTk.PhotoImage(rotated_image)

                # Reload the rotated image
                self.load_image()
                self.status_label.config(text=f"Image auto-rotated by {orientation}°!", bg="#27ae60")
            else:
                self.status_label.config(text="Image is already upright.", bg="#27ae60")
        except Exception as e:
            messagebox.showerror("Error", f"Unable to auto-rotate image: {e}")

    def load_image(self):
        """Load the current image, using preloaded cache or loading on demand."""
        try:
            image_path = self.image_files[self.current_image_index]

            # Use preloaded image if available
            if image_path in self.preloaded_images:
                self.photo = self.preloaded_images[image_path]
            else:
                # Load and resize on demand
                image = Image.open(image_path)
                width = self.winfo_screenwidth() - 200
                height = self.winfo_screenheight() - 300
                image = image.resize((width, height), Image.LANCZOS)
                self.photo = ImageTk.PhotoImage(image)
                self.preloaded_images[image_path] = self.photo  # Add to cache

            self.canvas.create_image(self.canvas.winfo_width() // 2, self.canvas.winfo_height() // 2, image=self.photo)

            # Update labels and entry
            self.rename_text.delete(0, 'end')
            self.rename_text.insert(0, image_path)
            self.rename_text.select_range(0, 'end')
            self.rename_text.focus()

            self.title(f"Image Renamer - {image_path}")
            self.top_image_label.config(text=f"Current Image: {image_path}")

            self.status_label.config(text="Image loaded successfully.", bg="#27ae60")
        except Exception as e:
            messagebox.showerror("Error", f"Unable to load image: {e}")

    def show_prev_image(self, event=None):
        self.current_image_index = (self.current_image_index - 1) % len(self.image_files)
        self.load_image()

    def show_next_image(self, event=None):
        self.current_image_index = (self.current_image_index + 1) % len(self.image_files)
        self.load_image()

    def rename_image(self):
        current_img = self.image_files[self.current_image_index]
        image_extension = current_img.split(".")[-1]
        new_name = self.rename_text.get()

        if not new_name:
            self.status_label.config(text="Rename canceled: empty name.", bg="#c0392b")
            return

        if not new_name.endswith(image_extension):
            new_name = f"{new_name}.{image_extension}"

        new_path = os.path.join(self.rename_folder, new_name)
        if os.path.exists(new_path):
            messagebox.showwarning("Rename Warning", "A file with this name already exists. Please use a different name.")
            return

        try:
            os.rename(current_img, new_path)
            self.image_files[self.current_image_index] = new_name
            self.status_label.config(text=f"Renamed to: {new_name}", bg="#27ae60")
            self.show_next_image()
        except Exception as e:
            messagebox.showerror("Rename Error", f"An error occurred while renaming: {e}")
    def manual_rotate_image(self):
        """Manually rotate the image by 90 degrees."""
        try:
            image_path = self.image_files[self.current_image_index]
            image = Image.open(image_path)

            # Rotate the image 90° counterclockwise
            rotated_image = image.rotate(-90, expand=True)
            rotated_image.save(image_path)

            # Update the preloaded image
            width = self.winfo_screenwidth() - 200
            height = self.winfo_screenheight() - 300
            rotated_image = rotated_image.resize((width, height), Image.LANCZOS)
            self.preloaded_images[image_path] = ImageTk.PhotoImage(rotated_image)

            # Reload the rotated image
            self.load_image()
            self.status_label.config(text="Image rotated manually by 90°.", bg="#27ae60")
        except Exception as e:
            messagebox.showerror("Error", f"Unable to rotate image manually: {e}")


if __name__ == "__main__":
    app = GalleryApp()
    app.mainloop()
