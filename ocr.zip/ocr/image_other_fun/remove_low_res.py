import os
from PIL import Image

# Specify the dimensions
MIN_WIDTH = 496 + 1
MIN_HEIGHT = 240 + 1

# Get the current directory
current_dir = os.getcwd()

# Walk through the directory tree
for root, dirs, files in os.walk(current_dir):
    for filename in files:
        file_path = os.path.join(root, filename)
        try:
            # Open the image file
            with Image.open(file_path) as img:
                # Check if the image dimensions are smaller than the threshold
                if img.width < MIN_WIDTH or img.height < MIN_HEIGHT:
                    print(f"Deleting {file_path} (Dimensions: {img.width}x{img.height})")
                    os.remove(file_path)
        except Exception as e:
            # Skip files that are not images
            print(f"Skipping {file_path}: {e}")

print("Completed cleaning up images.")
