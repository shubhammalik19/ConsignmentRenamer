SELECT
    DISTINCT `acc`,
    `accounts`.`acc_name`,
    SUM(`dr_amt`) AS `dr_amt`,
    SUM(`cr_amt`) AS `cr_amt`,
    (`accounts`.`op_bal` - `accounts`.`op_bal_cr`) AS `op_bal`,
    GROUP_CONCAT(`bill_no`) AS `bill_nos`,
    GROUP_CONCAT(`pod_no`) AS `pod_nos`
FROM
    (
        SELECT
            'Bill' AS `type`,
            `party` AS `acc`,
            `net_amt` AS `dr_amt`,
            0 `cr_amt`,
            bill_no,
            '' pod_no
        FROM
            `bill`
        WHERE
            `bill_date` BETWEEN '2024-04-01'
            AND '2025-03-31'
            AND `company_name` = 'DHAN LAXMI LOGISTIC'
            AND `net_amt` > 0
        UNION
        ALL
        SELECT
            'POD' AS `type`,
            `pon_ac` AS `acc`,
            `net_bal` `dr_amt`,
            0 AS `cr_amt`,
            '' bill_no,
            `pod_no`
        FROM
            `pod`
        WHERE
            `pod_date` BETWEEN '2024-04-01'
            AND '2025-03-31'
            AND `company_name` = 'DHAN LAXMI LOGISTIC'
            AND `pod`.`bill_status` = 'Unbilled'
            AND `net_bal` > 0
        UNION
        ALL
        SELECT
            'POD' AS `type`,
            `pon_ac` AS `acc`,
            0 `dr_amt`,
            `receipt` AS `cr_amt`,
            '' bill_no,
            `pod_no`
        FROM
            `pod`
        WHERE
            `pod_date` BETWEEN '2024-04-01'
            AND '2025-03-31'
            AND `company_name` = 'DHAN LAXMI LOGISTIC'
            AND `pod`.`bill_status` = 'Unbilled'
            AND `receipt` > 0
    ) AS `cat`
    INNER JOIN `accounts` ON `cat`.`acc` = `accounts`.`acc_id`
WHERE
    `company_name` = 'DHAN LAXMI LOGISTIC'
    AND `accounts`.`acc_name` != ''
    AND `accounts`.`acc_name` = 'RAJESH GUPTA'
GROUP BY
    `acc`;