from google.cloud import vision
from google.protobuf.json_format import MessageToDict
import os
import re
import sys
from PIL import Image
import shutil
import time
import db_connector
import logging
# Configure logging to write to a file
logging.basicConfig(
    filename="debug.log",  # File where logs will be stored
    level=logging.DEBUG,   # Log level
    format="%(asctime)s - %(levelname)s - %(message)s"
)
# Establish a connection
db_connection = db_connector.connect_to_database()


from datetime import datetime

from datetime import datetime

def clean_text_from_removal_list(extracted_text, removal_list):
    """
    Cleans the input text by removing unwanted words or phrases specified in the removal list.

    Args:
        extracted_text (str): The text to be cleaned.
        removal_list (list): A list of words or phrases to remove from the text.

    Returns:
        str: The cleaned text.
    """
    # Normalize spaces in the extracted text
    cleaned_text = re.sub(r"\s+", " ", extracted_text.strip())

    # Iterate through the removal list and remove each pattern
    for item in removal_list:
        # Escape the removal item for regex safety and replace it with an empty string
        pattern = re.escape(item)
        cleaned_text = re.sub(pattern, "", cleaned_text, flags=re.IGNORECASE)

    # Normalize extra spaces left after removal
    cleaned_text = re.sub(r"\s+", " ", cleaned_text).strip()

    return cleaned_text

def is_valid_date_and_year(date_str, date_format="%Y-%m-%d"):
    """
    Checks if a given date string is valid based on the provided format
    and whether the year is greater than 2022.

    Args:
        date_str (str): The date string to check.
        date_format (str): The format the date string should follow. Default is "%Y-%m-%d".

    Returns:
        bool: True if the date is valid and the year is > 2022, False otherwise.
    """
    try:
        # Parse the date string
        date_obj = datetime.strptime(date_str, date_format)
        # Check if the year is greater than 2022
        return date_obj.year > 2022 and date_obj.year < 2026
    except ValueError:
        # If parsing fails, the date is invalid
        return False

def fetch_gr_no_from_table(consignment_number, company_name, isSeparateImage, CONSIGNMENT_DATE):
    """
    Fetches the GR No. from the database table based on the consignment number.
    Returns a tuple of (gr_no, gr_date) if found, otherwise None.
    """
    global db_connection

    # Initialize variables
    gr_no2 = None
    gr_date = None

    # Validate CONSIGNMENT_DATE and derive financial year start date
    if CONSIGNMENT_DATE and is_valid_date_and_year(CONSIGNMENT_DATE):
        gr_date = get_financial_year_start_date(CONSIGNMENT_DATE)
    #print(f"gr_date: {gr_date}")
    # Handle special cases for isSeparateImage
    if isSeparateImage in ['GRF', 'VTC']:
        gr_no2 = f"{isSeparateImage}-{consignment_number}"

    try:
       
        params = [consignment_number]

        # Add `gr_no2` logic if set
        if gr_no2:
             # Build the base query
            query = """
                SELECT `gr_no`, DATE_FORMAT(`gr_date`, '%d-%m-%Y') AS `gr_date`
                FROM `jagdamba`
                WHERE (`gr_no` = %s or gr_no = %s)
            """
            params.append(gr_no2)
        else:
             # Build the base query
            query = """
                SELECT `gr_no`, DATE_FORMAT(`gr_date`, '%d-%m-%Y') AS `gr_date`
                FROM `jagdamba`
                WHERE `gr_no` = %s
            """
            

        # Add `company_name` logic
        #print(f"company_name: {company_name}")
        if company_name:
            query += " AND `company_name` = %s"
            params.append(company_name)

        # Add `gr_date` logic if set
        if gr_date:
            query += " AND `gr_date` >= %s"
            params.append(gr_date)

        # Log the query and parameters for debugging
        #logging.debug("Executing Query: %s", query)
        #logging.debug("With Parameters: %s", params)

        # Print the query and parameters for debugging
        #formatted_query = query % tuple(map(lambda x: f"'{x}'" if isinstance(x, str) else x, params))
        #print(f"Executing Query: {formatted_query}")

        # Execute the query
        cursor = db_connection.cursor(buffered=True)
        cursor.execute(query, tuple(params))
        result = cursor.fetchone()

        if company_name=='org' and not result:
            # attach hpr to consignment number
            consignment_number = f"HPR-{consignment_number}"
            consignment_number2 = f"NDA-{consignment_number}"
            query = """
                SELECT `gr_no`, DATE_FORMAT(`gr_date`, '%d-%m-%Y') AS `gr_date`
                FROM `jagdamba`
                WHERE (`gr_no` = %s or `gr_no` = %s) and `company_name` = 'jagdamba'  
            """
            cursor.execute(query, (consignment_number,consignment_number2))
            result = cursor.fetchone()

        # Return the GR No. and GR Date or None if not found
        return (result[0], result[1]) if result else None
    except Exception as e:
        logging.error(f"Error fetching GR No. for {consignment_number} from {company_name}: {e}")
        return None
    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()



def get_financial_year_start_date(CONSIGNMENT_DATE):
    """
    Returns the start date of the financial year based on the given consignment date.
    Financial year starts on April 1.
    
    :param CONSIGNMENT_DATE: A string representing the date in "DD/MM/YYYY" or "DD-MM-YYYY" format.
    :return: A string representing the financial year's start date in "DD/MM/YYYY" format.
    """
    #print(f"START RUNNING FIN: {CONSIGNMENT_DATE}")
    try:
        # Normalize the date format
        CONSIGNMENT_DATE = CONSIGNMENT_DATE.replace("-", "/")
        #print(f"CONSIGNMENT_DATE: {CONSIGNMENT_DATE}")
        consignment_date_obj = datetime.strptime(CONSIGNMENT_DATE, "%d/%m/%Y")
        #print(f"consignment_date_obj: {consignment_date_obj}")
        # Extract the year and month from the date
        year = consignment_date_obj.year
        month = consignment_date_obj.month
        
        # Determine the financial year start date
        if month >= 4:  # From April to December, the financial year starts on April 1 of the same year
            start_date = datetime(year, 4, 1)
        else:  # From January to March, the financial year starts on April 1 of the previous year
            start_date = datetime(year - 1, 4, 1)

        # Return the start date in YYYY-M-D format
        #print(f"Financial Year Start Date: {start_date.strftime('%Y-%m-%d')}")
        return start_date.strftime("%Y-%m-%d")
    except Exception as e:
        print(f"Error processing financial year start date: {e}")
        return None


# Test the function
def handle_file_move(isSeparateImage,file_path, company_folder, financial_year, consignment_number, image_dir, consignment_number2=None):
    """
    Handles moving or copying files to their designated directories.
    """
    try:
       
        company_name = company_folder
        if not company_name and not isSeparateImage:
            company_name = 'DISCARD'
            company_folder = 'DISCARD'
        if consignment_number:
            company_folder_path = os.path.join(image_dir, company_folder)
        else:
            company_folder_path = os.path.join(image_dir, f"{company_folder}/UNKNOWN")
        
        
        if isSeparateImage=='GRF':
            if consignment_number:
              company_folder_path = os.path.join(image_dir, 'GRF')
            else:
              company_folder_path = os.path.join(image_dir, 'GRF/UNKNOWN')

        if isSeparateImage=='VTC':
            if consignment_number:
               company_folder_path = os.path.join(image_dir, 'VTC')
            else:
                company_folder_path = os.path.join(image_dir, 'VTC/UNKNOWN')

        if financial_year and company_name!='DISCARD' and consignment_number:
            company_folder_path = os.path.join(company_folder_path, financial_year)

        #print(f"company_folder_path: {company_name}")
        if company_name=='jag' and not consignment_number and consignment_number2:
            consignment_number = consignment_number2
            #print(f"company_folder_path: {company_folder_path}")
        
        if not consignment_number and consignment_number2:
            consignment_number = consignment_number2

        if not consignment_number:
            # give some random number
            random_number = str(int(time.time()))
            consignment_number = f"UNKNOWN-{random_number}"
            
        os.makedirs(company_folder_path, exist_ok=True)
        new_file_path = os.path.join(company_folder_path, f"{consignment_number}.jpg")
        
        if not os.path.exists(new_file_path):
            shutil.move(file_path, new_file_path)
            #print(f"File moved to: {new_file_path}")
            pass
        else:
            # rename file in current directory to duplicate dir
            duplicate_dir = os.path.join(image_dir, 'DUPLICATE')
            new_file_path = os.path.join(duplicate_dir, f"{consignment_number}.jpg")
            if not os.path.exists(new_file_path):
                shutil.move(file_path, new_file_path)
                #print(f"File moved to: {new_file_path}")
            else:
                random_number = str(int(time.time()))
                new_file_path = os.path.join(duplicate_dir, f"{consignment_number}-{random_number}.jpg")
                shutil.move(file_path, new_file_path)
            #print(f"File already exists: {new_file_path}")
        
        return new_file_path
    except Exception as e:
        print(f"Error handling file move: {e}")
        return None
    


    
# create log file
#sys.exit()

def replace_grn_numbers(match):
    grn_number = int(match.group(1))  # Extract the number after GRN
    next_number = match.group(2)      # Extract the next number
    # get first digit of next number
    next_number_first_digit = int(next_number[0])
    if next_number_first_digit==0:
     combined_number = f"{grn_number}{next_number}"  # Combine GRN incremented number with next number
     return f"GRN {combined_number}"  # Format the replacement
    
    return None
def clean_text(input_text,IS_DOCET_NUMBER,company_name,isSeparateImage):
    """
    Cleans the input text by removing specified patterns including city-specific 
    addresses, phone lines, emails, CONSIGNOR/CONSIGNEE details, ISO lines, 
    and other unwanted text.
    """
    #print("input_text",input_text)
    #sys.exit()
    # List of unwanted words/phrases to remove
    to_be_removed = [
        "Meerut-*", "GHAZIABAD-*", "AGRA-*", "MUZAFFARNAGAR-*", "DEHRADUN0-*", "DEHRADUN-*", "MATHURA-*", "BALOTRA-*",'Pradesh-*',
        "ALIGARH-*", "PILKHUWA-*", "PANIPA-*", "FARIDABAD-*", "SANJAY GANDHI TPT NAGAR-*","Shamli-*",'u-852961','3391a07664',
        "Agra", "Aligarh", "Baghpat", "Baraut", "Bareilly", "Bulandshahar", "Dehradun", "Deoband", "Etah","ISO 9001: 2008 Certified","9001: 2008","9001:2008",
        "Farrukhabad", "Firozabad", "Ghaziabad", "Hapur", "Haridwar", "Hathras", "Itawa", "Jhansi", "Jawalapur","-247001",
        "Kairana", "Kandhla", "Kasganj", "Khatauli", "Khurja", "Kosi-Kalan", "Lalitpur", "Mainpuri", "Mathura",
        "Mawana", "Meerut", "Modinagar", "Moradabad", "Mussoorie", "Muzaffamagar", "Noida", "Pilkhuwa", "Rampur",'09dptps3451eszc',
        "Rishikesh", "Roorkee", "Saharanpur", "ardhana", "Shamli", "Shikohabad", "Sikandrabad", "Sikandra-u",
        "Sirsaganj", "Tundia", "Vikasnagar", "No. of Pkgs.", "TERMS & CONDITION", "TERMS & CONDITIONS",'09aabfl5796p1',
        "TERMS AND CONDITIONS", "TERMS AND CONDITION", "PRINTED OVERLEAF", "Brop", "Fleam", "Rio Powood",".00"
        "Consignee Copy", "DRIVER COPY", "NOTICE", "The consignment covered by this", "receipt from shall be stored","09agspv5532c1zz",'UP. - 201009',
        "control of the transport operator", "delivered to or", "to the order of the consignees",
        "It shall under no circumstances", "to any one without the written authority", "consignee, bank or its order","STOP24047719","Fleet Owners & Transport Contractors","Fleet Owners","Transport Contractors","&","& Transport Contractors","що",
        "endorsed on the consignee's copy", "or on a separate letter of authority","Rishikash", "Rishikesh","Sardhana",",Sardhana",",","•Relay Best werk","Retail Sove","8)",
        "Sardhana", "Shami", "Sikandra-rau", "Tundla","GRB","ORGANIZATION 0742",'09aaacp0132h126',
        "D-47, Sector-22, Industrial Area, Road, Near Bhatta No-5, (U.P.) -201 003, India","09aabfl5796p1ze",
        "D-47", "Sector-22", "Industrial Area", "Road", "Near Bhatta No-5", "(U.P.)", "India",'7110/2023','334-07-2016-0078',
        "PACKAGE INFORMATION", "NO. OF", "PKGS.", "TYPE OF", "PACKING", "SAID TO CONTAIN", "SAD","FROM","TRANSPORT ORGANIZATION 0742",
        "(U.P.)", "E:", "Website:", "PKGS.", "TO","201 003","003","Nagina","licable",": :","Consignor M/s.","d by:",'.',"سد","ST0924051289","ST0924051227","F-118","Sector-8",
        "F-118", "Free Ganj", "AT OWNER'S RISK","INSURANCE","224118, 9286876252","9719994789","9917782598","The customer has stated that:","9897263226","9910485151","9319518025","He has nor insured the consignment","OR",
        "He has insured the consignment","Company:","9634636161","9760015347","Policy No.:","Amount","8534916541, 8439230001","F-118, Sector-8",
        "9560501563, 9911864317",'hasra No.-233 Vill-Mo',"sto ' Vill-Mo","CARTON MEDICINE","09910485151","9350040541","DRSH","COURT","mojte","set of special lorry receipt form shall be stored at the","destination under the and shall be the","CONSIGNOR MISHARAMPAL SATYAPAL","( Pkgs.",
        "no-339FA","8923300601935822246","892330060","1935822246","GSTIN-09AADCL0646F1ZO","09AADCL0646F1ZO","24253451600973","Act 2007","Carriage By Act 2007","Registration No. UP-14-07-2016-0078","UP-14-07-2016-0078","Sikandra-", "rau","04 Can","JOWAR RS-086 ()","260124007174","NTC-",
        "Fleet Owners & Transport Contractors 0742","fleet owners & transport contractors 0742","0742","09aaacd01324126",'carriage no 314','grm','201003'
    ]
    if isSeparateImage=='VTC':
        # add 224118 to to_be_removed 
        to_be_removed.append('224118')
        to_be_removed.append('224118,')
        
   
        
    # Regex patterns for specific unwanted text
    patterns = {
        "address": r"(H\. O\.|B\. O\.).*",
        "address2": r"(H\.O\.:.*?)(\n|$)|B\.O\.:.*?(\n|$)|H\.O::.*?(\n|$)|B\.O::.*?(\n|$)",  # H.O. and B.O. variations
        "phone": r"(Phone No\.?:|Mob\.?:).*?(\n|$)",  # Matches phone variations
        "consignor": r"(CONSIGNOR MS|CONSIGNOR M/S).*?(\n|$)",  # Matches CONSIGNOR MS or M/S
        "consignee": r"(CONSIGNEE M/S).*?(\n|$)",  # Matches CONSIGNEE M/S
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",  # Matches emails
        "gstin": r"GSTIN:.*?(\n|$)",  # Matches GSTIN lines
        "iso": r"ISO.*?(\n|$)",  # Matches ISO lines
        "mob_variations": r"Mob\s*:?.*?(\n|$)",  # Matches 'Mob' variations
        "ph_variations": r"Ph\s*:?.*?(\n|$)",  # Matches 'Ph' variations
        "plus91": r"\+91-?\s*\d+.*?(\n|$)",  # Matches phone numbers starting with +91,
        "description": r"DESCRIPTION\s*[:\-]?\s*(.*?)(\n|$)",  # Matches "DESCRIPTION" followed by text until newline
        "rio_powood": r"Rio Powood\s*[:\-]?\s*(.*?)(\n|$)",
        "Nove": r"Nove\s*[:\-]?\s*(.*?)(\n|$)",
        "invoice": r"INVOICE\s*[:\-]?\s*(\d+)",  # Matches "INVOICE" followed by a number
        "bill_no": r"BILL\s*NO\s*[:\-]?\s*(\d+)",  # Matches "BILL NO" followed by a number
        
        "email2": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",  # Matches emails
        "website": r"\b(?:https?://)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?\b",  # Matches URLs
        "bo": r"B\.?\s*O\.?\s*:?.*?(\n|$)",  # Matches B.O. variations
        "head_office": r"Head\s*Office\s*:.*?(\n|$)",  # Matches "Head Office:" followed by any text until newline,
        "gst_no": r"\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}",  # Matches GST numbers
        "mobile": r"\b\d{10}\b",  # Matches 10-digit mobile numbers,
        "long_digits": r"\b\d{10,}\b",  # Matches any digit length greater than 10
        "head_office_address": r"(Head Office[:.:]*)[^\n]*",  # Matches "Head Office" followed by any text until newline
        "number_slash_number": r"\b\d+/\d+\b",  # Matches numbers separated by a slash

    }

    # Apply regex patterns to clean specific unwanted text
    for name, pattern in patterns.items():
        input_text = re.sub(pattern, "", input_text, flags=re.IGNORECASE)
    
    cleaned_text = input_text
    #print(cleaned_text)
    #sys.exit()
    # Remove city and phrase patterns from `to_be_removed`
    for item in to_be_removed:
        # Handle patterns with wildcards
        if "-*" in item:
            #print(item)
            prefix = item.split("-*")[0]  # Extract prefix before `-*`
            #pattern = rf"\b{re.escape(prefix)}-\S+\b"  # Match the prefix followed by any text
        else:
            pattern = rf"\b{re.escape(item)}\b"
        cleaned_text = re.sub(pattern, "", cleaned_text, flags=re.IGNORECASE)
    #print(cleaned_text)
    #sys.exit()
    # if IS_DOCET_NUMBER then remove every digit less than  32892
     # Check if IS_DOCET_NUMBER is True
    if IS_DOCET_NUMBER and company_name=='jag':
        # Use regex to remove numbers less than 32892
        # Explanation:
        # \b - Ensures we match whole numbers
        # (\d+) - Captures any numeric value
        # A lambda function checks the value and retains only those >= 32892
        cleaned_text = re.sub(
            r'\b\d+\b',
            lambda match: match.group(0) if int(match.group(0)) >= 32892 else '',
            cleaned_text
        )
    if isSeparateImage=='GRF':
        # remove any digit > 100082
        cleaned_text = re.sub(
            r'\b\d+\b',
            lambda match: match.group(0) if int(match.group(0)) <= 100082 else '',
            cleaned_text
        )
    if company_name=='jag':
        # add DOCKET NUMBER  at first line
        cleaned_text = 'DOCKET NUMBER \n' + cleaned_text
        

    #print(cleaned_text)
    #sys.exit()

    #if company_name=='org':
        # Replace `: , G` with `GRN.` but not if it is already `: , GRN`
        #print(cleaned_text);
        
        

    # Apply regex patterns to remove matching lines
   
    """ for name, pattern in patterns.items():
        cleaned_text = re.sub(pattern, "", cleaned_text, flags=re.IGNORECASE) """

   

    # Replace broken words
    replacements = { 
        r"\bCKET\b": "DOCKET ",  # Replace 'CKET' with 'DOCKET'.
        r"\bGRN:\b": "GRN. ",  # Replace 'CKET' with 'DOCKET' Goods Receipt -
        r"\bGENO(\d+)\b": r"GRN10\1",  # Replace 'GENO<number>' with 'GRN10<number>'
        r"\bGRNO(\d+)\b": r"GRN10\1",  # Replace 'GENO<number>' with 'GRN10<number>'
        r"\bGRNO\b": "GRN0",  # Replace 'GRNO' with 'GRN0'
        r"\bGRN\b": "GRN ",  # Replace 'GRN' with 'GRN.'
       
        r"\bGRN\s*\.\b": "GRN.",
        
        r"Goods Receipt\s*-\s*": "GRN ",    # Replace 'Goods Receipt -' with 'GRN.'
        r"\binment\b": "Invoice",
        r"\bZVS-\b": "ZYS-",  # Replace 'ZVS' with 'ZYS'
        r"\bŻYS-\b": "ZYS-",  # Replace 'ZVS' with 'ZYS'
        r"\bPNP\b": "PNP-",
        r"\bPNP--\b": "PNP-", # Replace 'PNP' with 'PNP-'
        r"\bNo\.\s*\n\s*DATED\b": "Consignment Note", # Replace 'No. DATED' with 'Consignment Note'
        r"\bGRN\.\s+\.\b": "GRN.",
        r"\bGRN(?=\d)": "GRN. ",  # Replace 'GRN<number>' with 'GRN. <number>'
        r"\bGRN\s*\.\s*\b": "GRN.",  # Replace 'GRN . ' with 'GRN.'
        r"\bGRN\.Date\b": "GRN.",
        r"\bGRILL WITH GRN\b": "GRN.",
    }

    # Apply replacements for broken words
    for broken_word, replacement in replacements.items():
        cleaned_text = re.sub(broken_word, replacement, cleaned_text, flags=re.IGNORECASE)

    # Regex pattern to match 'Date' and ensure it's replaced with ' Date'
    pattern = r"(?<!\s)Date"

    # Replacement to add a space before 'Date'
    replacement = r" Date"

    # Apply the replacement
    cleaned_text = re.sub(pattern, replacement, cleaned_text)
    

    #print(f"Cleaned Text: {cleaned_text}")
    #sys.exit()

    # Regex to replace "GR. No" with "GRN"
    pattern = r"\bGR\. No\b"
    cleaned_text = re.sub(pattern, "GRN", cleaned_text)

    # Normalize spaces and newlines
    cleaned_text = re.sub(r"\s{2,}", " ", cleaned_text)  # Replace multiple spaces with one
    cleaned_text = re.sub(r"\n{2,}", "\n", cleaned_text)  # Replace multiple newlines with one

    #print("Initial Text:")
    #print("\n".join(cleaned_text.split("\n")[:5]))
    if company_name=='org':
        # Replace GRN0 with GRN1
        cleaned_text = re.sub(r"GRNO(\d+)", r"GRN10\1", cleaned_text)
       
        # Replace GRN0 with GRN1
        cleaned_text = re.sub(r"GRN0(\d+)", r"GRN10\1", cleaned_text)

        # Replace `GR TO` or `GR` with `GRN.`
        cleaned_text = re.sub(r"\bGR\s*TO\b", "GRN.", cleaned_text, flags=re.IGNORECASE)
        cleaned_text = re.sub(r"\bGR\b", "GRN.", cleaned_text, flags=re.IGNORECASE)

        # Normalize patterns like `: , , : , GR<number>` to `: , GRN.<number>`
        cleaned_text = re.sub(r": , , : , GR(\d+)", r": , GRN.\1", cleaned_text)

        # Handle `G1<number>` replacements with `GRN.<number>`
        cleaned_text = re.sub(r": , G1(\d+)(?!RN\.)", r": , GRN.\1", cleaned_text)

         # Handle `G1<number>` replacements with `GRN.<number>`
        cleaned_text = re.sub(r": , G0(\d+)(?!RN\.)", r": , GRN. 0\1", cleaned_text)


         # Handle `G1<number>` replacements with `GRN.<number>`
        cleaned_text = re.sub(r": , G0(\d+)(?!RN\.)", r": , GRN. 0\1", cleaned_text)
    

        # Normalize patterns like `: , , : , GRQ<number>` to `: , GRN.0<number>`
        cleaned_text = re.sub(r": , GRQ(\d+)(?!RN\.)", r": , GRN. 0\1 ", cleaned_text)
        
        # Replace `GRILL<number>` with `GRN.<number>`
        cleaned_text = re.sub(r"GRILL(\d+)", r"GRN. \1", cleaned_text)


        # Replace `GR<NUMBER>` with `GRN.<NUMBER>`
        cleaned_text = re.sub(r"\bGR(\d+)\b", r"GRN.\1", cleaned_text)

        # Handle `GRO<number>` replacements with `GRN. 0<number>`
        cleaned_text = re.sub(r"GRO(\d+)", r"GRN. 0\1", cleaned_text)

         # Handle `GEO<number>` replacements with `GRN. 0<number>`
        cleaned_text = re.sub(r"GEO(\d+)", r"GRN. 0\1", cleaned_text)

        #print(cleaned_text)
        
        #sys.exit()

        # Perform replacement
        pattern = r"GRN(\d+)\s+(\d+)"
        cleaned_text = re.sub(pattern, replace_grn_numbers, cleaned_text)

        # remove digit less than 44542
        cleaned_text = re.sub(
            r'\b\d+\b',
            lambda match: match.group(0) if int(match.group(0)) >= 2500 else '',
            cleaned_text
        )

        # Regex to match digits with length > 7
        pattern = r"\b\d{8,}\b"
        cleaned_text = re.sub(pattern, "", cleaned_text)
        cleaned_text = re.sub(r"\s{2,}", " ", cleaned_text).strip()

        cleaned_text = 'GRN. ' + cleaned_text

        # Regex to match "GRM" followed by digits
        pattern = r"GRM(?=\d+)"
        cleaned_text = re.sub(pattern, "", cleaned_text)

        # Regex to match "GRM" followed by digits
        pattern = r"N(?=\d+)"
        cleaned_text = re.sub(pattern, "", cleaned_text)


        
    if isSeparateImage=='VTC':
        # Regex to match numbers less than 3 digits in length or less than 1000
        pattern = r"\b0*\d{1,2}\b|\b0*[1-9]\d{1,2}\b(?!\d)"

        # Remove the matched numbers
        cleaned_text = re.sub(pattern, "", cleaned_text)
        cleaned_text = re.sub(r"\s{2,}", " ", cleaned_text).strip()
        # remove 000nvoice or any number in front of in next line to Invoice or Invoice No or Invoice No.
         # Define patterns to clean unwanted prefixes or numbers after Invoice keywords


        # Regex to match and remove the "VTC" prefix
        pattern = r"\bVTC(\d+)\b"
        cleaned_text = re.sub(pattern, r"\1", cleaned_text)

        # Regex to match "GRN.: DR<number>" and keep only "GRN.<number>"
        pattern = r"(GRN\.\s*:?\s*)[A-Za-z]+(?=\d+)"

        # Replace the matched prefix with "GRN."
        cleaned_text = re.sub(pattern, r"\1", cleaned_text)

        # Clean up extra spaces if needed
        cleaned_text = re.sub(r"\s{2,}", " ", cleaned_text).strip()
        patterns = [
            r"000\s*nvoice\b",                # Matches `000nvoice`
            r"000 Invoice\b",                 # Matches `000 Invoice`
            r"\.nvoice\b",                    # Matches `.nvoice`
            r"000\s*nvoice\s*:\s*\d+",        # Matches `000 Invoice: number`
            r"(^\d{1,4})\s*\n\s*Invoice:",    # Matches standalone numbers on the previous line with `Invoice:`
            r"(^\d+)\s+Invoice:",             # Matches numbers directly before `Invoice:`
            r"(Invoice:+)\s*\d+",             # Matches `Invoice:::` or `Invoice::` followed by digits
            r"(Invoice)\s*\n\s*(\d{7,})",     # Matches large numbers (7+ digits) directly after `Invoice`
            r"(Invoice:)\s*\d+",              # Matches `Invoice:` followed by digits
            r"(^224118)\s*\n\s*Invoice:",  # Matches standalone numbers on the previous line with `Invoice:`
            r"\b\d+:\s*\d+\b"
            
        ]

    if company_name=='jagdamba':
        patterns = [
            r"000\s*nvoice\b",                # Matches `000nvoice`
            r"000 Invoice\b",                 # Matches `000 Invoice`
            r"\.nvoice\b",                    # Matches `.nvoice`
            r"000\s*nvoice\s*:\s*\d+",        # Matches `000 Invoice: number`
            r"(^\d{1,4})\s*\n\s*Invoice:",    # Matches standalone numbers on the previous line with `Invoice:`
            r"(^\d+)\s+Invoice:",             # Matches numbers directly before `Invoice:`
            r"(Invoice:+)\s*\d+",             # Matches `Invoice:::` or `Invoice::` followed by digits
            r"(Invoice)\s*\n\s*(\d{7,})",     # Matches large numbers (7+ digits) directly after `Invoice`
            r"(Invoice:)\s*\d+",              # Matches `Invoice:` followed by digits
            r"(^224118)\s*\n\s*Invoice:",  # Matches standalone numbers on the previous line with `Invoice:`
            r"Invoice_No:\s*/\d+",  # Matches numbers directly before `Invoice No:`
        ]

        # Apply each pattern to clean the text
    for pattern in patterns:
        cleaned_text = re.sub(pattern, "Invoice:", cleaned_text, flags=re.IGNORECASE | re.MULTILINE)


    patterns2 = [ 
            r"(GR\. No\.\s*)C(\d+)",  
    ]
    for pattern in patterns2:
        cleaned_text =  re.sub(
        pattern, 
        lambda m: m.group(1) + m.group(2) if len(m.groups()) > 1 else m.group(0),  # Safely handles cases without enough groups
        cleaned_text, 
        flags=re.IGNORECASE
    )



    #print("\nAfter ': , G' Replacement:")
    #print("\n".join(cleaned_text.split("\n")[:5]))
    #print(cleaned_text)
    #sys.exit()
    return cleaned_text.strip()

def clean_dates_from_text(text):
    """
    Removes dates in the formats dd-mm-yyyy or dd/mm/yyyy from the given text.
    
    :param text: The input string to clean.
    :return: The cleaned text with dates removed.
    """
    # Define regex for dates (dd-mm-yyyy or dd/mm/yyyy)
    date_pattern = r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b"
    
    # Replace all matched dates with an empty string
    cleaned_text = re.sub(date_pattern, "", text)
    
    # Normalize extra spaces left behind after removal
    cleaned_text = re.sub(r"\s{2,}", " ", cleaned_text).strip()

    pattern = r"\b\d{1,4}/\d{1,4}\b"
    cleaned_text = re.sub(r"\s+", " ", cleaned_text).strip()
    
    return cleaned_text

def fetch_number_near_gr_no(text):
    """
    Extracts the 4-9 digit number closest to 'GR. No.' in the text.
    Considers both preceding and succeeding numbers.
    """
    # Updated regex to capture numbers before and after 'GR. No.'
    pattern = r"(?:\b(\d{4,9})\b).*?GR\.?\s*No\.?|GR\.?\s*No\.?.*?\b(\d{4,9})\b"
    
    # Debugging text structure
    #print("Debugging Text Structure:")
    #print(repr(text))

    # Search for the pattern
    matches = re.findall(pattern, text, re.IGNORECASE | re.DOTALL)
    
    # Debugging matches
    #print("Matches Found:", matches)
    
    # Flatten matches and remove empty entries
    numbers = [num for match in matches for num in match if num]
    
    # Return the first number closest to 'GR. No.'
    if numbers:
        #print("Filtered Numbers:", numbers)
        return numbers[0]
    
    #print("No match found.")
    return None
# Function to remove prefixes or suffixes
def remove_prefix_suffix(consignment_number):
     # REMOVE PREFIXES OR SUFFIXES
    TO_REMOVE = [
        "CONSIGNMENT NOTE",
        "CONSIGNMENT",
        "NOTE",
        "DOCKET NUMBER",
        "DOCKET",
        "NUMBER",
        "DEEN",
        "DEEN.",
        "Doon",
        "GRN",
        "GRM",
        "GRN.",
        "NO",
        "NO.",
        "NO-",
        "DATED",
        "DATE",
        "EWB. No.",
        "EWB No.",
        "EWB",
        "G.R. No.",
        "G.R.",
        "G.R",
        "GRN.",
        "GRN",
        "GR",
        "No.",
        "No",
        "No-",
        "GRIN",
    ]
    for prefix in TO_REMOVE:
        consignment_number = consignment_number.replace(prefix, "", 1).strip()
    return consignment_number

def clean_consignment_number(consignment_number):
    """
    Extracts only the numeric part of the consignment number, removing any non-numeric text.
    
    :param consignment_number: The input consignment number as a string.
    :return: The cleaned numeric part of the consignment number.
    """
   
    # Remove prefixes or suffixes
    consignment_number = remove_prefix_suffix(consignment_number)

    # Use regex to extract only the numeric part (6 to 12 digits)
    match = re.search(r"\b\d{3,9}\b", consignment_number)
    return match.group(0) if match else None


def fetch_company_name(text):
    """
    Searches for specific company names in the provided text and returns the matched name.
    
    :param text: The input text to search in.
    :return: The matched company name if found; otherwise, None.
    """
   
    if text is None:
        return None
    # Define company patterns with their return values
    company_patterns = {
        r"\bjagdamba transport organization[\w\W]*\b": "org",
        r"\bjagdamba[\w\W]*\b": "jagdamba",  # Matches 'jagdamba' with any trailing special characters
        r"\bejagdamba[\w\W]*\b": "jagdamba",
        r"\bjagdambad[\w\W]*\b": "jagdamba",
        r"\bJAGDANAA[\w\W]*\b": "jagdamba",  # Matches 'jagdamba' with any trailing special characters
        r"\bvikram[\w\W]*\b": "jagdamba",  # Maps 'vikram' to 'jagdamba'
        r"\bvikramd[\w\W]*\b": "jagdamba",  # Maps 'vikram' to 'jagdamba'
        r"\bjag[\w\W]*\b": "jag",
        r"\bjagd[\w\W]*\b": "jag",
        r"\bwings[\w\W]*\b": "jag",
        r"\bwingsd[\w\W]*\b": "jag",

        
    }

    # Normalize text to lowercase for case-insensitive matching
    text = text.lower()
    #print(f"Normalized Text: {text}")
    #print(f"Debug: Input Text:\n{text}")
    #sys.exit()
    # Direct matches for "org"

     # Check for "jagdamba transport organization"
    if "jagdamba transport organization" in text:
        #print("jagdamba transport organization")
        return "org"
    
    if "09adgpm7516e1zi" in text.lower() or "jagdamba transport organization" in text.lower() or "transport organization" in text.lower():
        return "org"
    
    #print(f"Debug: Company Name Patterns:" +text)
    # Loop through patterns and search for matches
    for pattern, return_value in company_patterns.items():
        #print(f"Pattern: {pattern}")
        if re.search(pattern, text, re.IGNORECASE):
            #print(f"Matched: {return_value}")
            return return_value
    #sys.exit()
    # If no match is found, return None
    return None
def isSeparateThisImage(text):
    """
    Searches for specific transport names in the provided text and handles trailing spaces or special characters.
    
    :param text: The input text to search in.
    :return: The matched transport name if found; otherwise, None.
    """
    # Normalize the input text to lowercase for case-insensitive matching
    text = text.lower()
    #print(f"Debug: Input text normalized to lowercase:\n{text}")
    #sys.exit()
    # Debug: Check if text is None
    if text is None:
        print("Debug: Input text is None.")
        return None
    #09AASFG3534H2Z2 
    
    # Direct matches for "org"
    if "09aasfg3534h2z2" in text.lower() or "gayatri roadlines" in text.lower():
        return "GRF"
    
    if "09aabfl5796p1ze" in text.lower() or "lucknow bareilly goods" in text.lower():
        return "LUCKNOW BARRELY"
    
    if "09dptps3451e2zc" in text.lower() or "bareilly chandausi" in text.lower():
        return "BAREILLY CHANDOSI"
    
    if "09accpz5597r1z7" in text.lower() or "amroha golden" in text.lower():
        return "AGTC"
    # Define transport patterns with their return values
    transport_patterns = {
        r"\bsanjeev golden[\s\W]*": "SANJEEV GOLDEN",  # Matches "SANJEEV GOLDEN" with potential trailing characters
        r"\bbareilly chandausi[\s\W]*": "BAREILLY CHANDOSI",  # Matches "BAREILLY CHANDOSI"
         r"\bsaveilly chandausi[\s\W]*": "BAREILLY CHANDOSI",  # Matches "BAREILLY CHANDOSI"
        r"\blucknow bareilly[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blucknow bareilly[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blucknow beilly[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blucknow bargely[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blucknow reilly[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blbgc[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\bbareilly goods carriers[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\blbtc[\s\W]*": "LUCKNOW BARRELY",  # Matches "LUCKNOW BARRELY"
        r"\bjai durga[\s\W]*": "JAI DURGA",  # Matches "JAI DURGA"
        r"\bagarwal transport[\s\W]*": "AGGARWAL TRANSPORT",  # Matches "AGGARWAL TRANSPORT"
        r"\bambey transport[\s\W]*": "AMBEY TRANSPORT",  # Matches "AMBEY TRANSPORT"
        r"\baambey transport[\s\W]*": "AMBEY TRANSPORT",  # Matches "AMBEY TRANSPORT"
        r"\bgarg goods[\s\W]*": "GARG GOODS",  # Matches "GARG GOODS"
        r"\bkuljeet transport[\s\W]*": "KULJEET TRANSPORT",  # Matches "KULJEET TRANSPORT"
        r"\bjagdish transport[\s\W]*": "JAGDISH TRANSPORT",  # Matches "JAGDISH TRANSPORT"
        r"\bshree durga[\s\W]*": "SHREE DURGA",  # Matches "SHREE DURGA"
        r"\bshri siddhi[\s\W]*": "SHRI SIDDHI",  # Matches "SHRI SIDDHI"
        r"\bshri\s*siddhi(?:\s*vinayak)?\s*roadline[\s\W]*": "SHRI SIDDHI VINAYAK",  # Matches "Shri Siddhi Vinayak Roadline"
        r"\bashoka\s*transport[\s\W]*": "ASHOKA TRANSPORT",  # Matches "Ashoka Transport"
        r"\bdtca[\s\W]*": "DTCA",  # Matches "DTCA"
        r"\bkapil malik[\s\W]*": "KAPIL MALIK GOODS TRANSPORT",  # Matches "kapil malik"
        r"\bswikriti transport[\s\W]*": "SWIKRITI TRANSPORT",  # Matches "WIKRITI TRANSPORT"
        r"\bdavesh freight[\s\W]*": "DAVESHA FREIGHT CRARRIER",  # Matches "WIKRITI TRANSPORT"
        r"\bshubham transport[\s\W]*": "SHUBHAM TRANSPORT",  # Matches "SHUBHAM TRANSPORT"
        r"\bradhika transport[\s\W]*": "SHUBHAM TRANSPORT",  # Matches "SHUBHAM TRANSPORT"
        r"\bgayatri roadlines[\s\W]*": "GRF",  # Matches "SHUBHAM TRANSPORT"
        r"\bayatri roadlines[\s\W]*": "GRF",  # Matches "SHUBHAM TRANSPORT"
        r"\bexpress carriers[\s\W]*": "EXPRESS CARRIERS",  # Matches "EXPRESS CARRIERS"
        r"\brama krishna[\s\W]*": "RAMA KRISHNA",  # Matches "RAMA KRISHNA"
        r"\bnew wahid goods[\s\W]*": "NEW WAHID GOODS",  # Matches "NEW WAHID GOODS"
        r"\bgoods transport service[\s\W]*": "GOODS TRANSPORT SERVICE",  # Matches "GOODS TRANSPORT SERVICE"
        r"\bshivai roadlines[\s\W]*": "SHIVAI ROADLINES",  # Matches "SHIVAI ROADLINES"
        r"\bvikram[\s\W]*": "VTC",  # Matches "VIKRAM"
        r"\bkhushdil[\s\W]*": "KHUSHDIL",  # Matches "KHUSHDIL"
        r"\bsubject sambhal jurisdiction[\s\W]*": "SUBJECT SAMBHAL JURISDICTION",  # Matches "SUBJECT SAMBHAL JURISDICTION"
        r"\bsambhal jurisdiction[\s\W]*": "SUBJECT SAMBHAL JURISDICTION",  # Matches "SAMBHAL JURISDICTION"
        r"\boxyzen[\s\W]*": "OXYZEN",  # Matches "OXYZEN",
        r"\bsiper bihar[\s\W]*": "OXYZEN",
        r"\baim express[\s\W]*": "AIM EXPRESS",  # Matches "AIM EXPRESS"
        
        
    }
   
    # Loop through each pattern and check for matches in the text
    for pattern, return_value in transport_patterns.items():
        #print(f"Debug: Checking pattern: {pattern}")
        if re.search(pattern, text):
            #print(f"Debug: Match found for pattern: {pattern}")
            #print(f"Debug: Matched Transport Name: {return_value}")
            return return_value

    # If no patterns match
    #print("Debug: No matches found.")
    return None

    
def fetch_single_date_and_validate(text):
    """
    Fetches the first valid date around 'DATED' or 'TIME', validates, and corrects it.
    If multiple dates are found, attempts to return the most accurate one.
    """
    # Regex patterns for dates around keywords
    date_patterns = [
        # Matches "DATED" followed by a date
        r"DATED\s*[:\-]?\s*(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})",
        # Matches "DATE" followed by a date
        r"DATE\s*[:\-]?\s*(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})",
        # Matches date directly above "TIME"
        r"(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})\s*\n\s*TIME",
        # Matches date on the next line after "DATED"
        r"DATED\s*[:\-]?\s*\n\s*(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})",
        # Matches date on the next line after "DATE"
        r"DATE\s*[:\-]?\s*\n\s*(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})",
        # Fallback: Matches any date-like string anywhere in the document
        r"(\d{1,3}[\/\-]\d{1,2}[\/\-]\d{2,4})"
    ]

    DATES = []  # To store all matched and validated dates
    for date_pattern in date_patterns:
        matches = re.finditer(date_pattern, text, re.IGNORECASE | re.DOTALL)
        for match in matches:
            raw_date = match.group(1)
            if raw_date:  # Only add if valid
                #print(f"Matched and validated date: {raw_date}")
                DATES.append(raw_date)

    # If multiple dates are found, select the best date
    
    DATES = list(set(DATES))
    #print(f"Found dates: {DATES}")
    if len(DATES) > 1:
        # Filter dates with a valid full year >= 2021
        valid_full_year_dates = [
            d for d in DATES if len(d.split("/")[-1]) == 4 and datetime.strptime(d, "%d/%m/%Y").year >= 2021
        ]
        if valid_full_year_dates:
            # Sort the full-year valid dates
            sorted_dates = sorted(valid_full_year_dates, key=lambda d: datetime.strptime(d, "%d/%m/%Y"))
            date = validate_and_assign_date(sorted_dates[0])
            # spilit cant be - or /

            if int(year) < 2021:
                date = validate_and_assign_date(DATES[0])
            return date
        else:
            #print("DATES[0] ", DATES[0])
            date = validate_and_assign_date(DATES[0]);
            year = date.split("/")[-1]
            if int(year) < 2021:
                date = validate_and_assign_date(DATES[1])
            return date

            

    
    # If only one date is found, return it
    if len(DATES) == 1:
        #print(f"Single date found: {DATES[0]}")
        return validate_and_assign_date(DATES[0])

    # If no dates are found, return None
    else:
        #print("No valid dates found.")
        return None


def validate_and_assign_date(date_str):
    """
    Validates and corrects a date string to the closest possible valid date.
    Handles both 'dd-mm-yyyy' and 'dd/mm/yyyy' formats.
    If invalid, assigns `31/01/YYYY`.
    :param date_str: The detected date string.
    :return: A valid date string in "DD/MM/YYYY" format or None if invalid.
    """
    try:
        # Replace "-" with "/" to normalize the format
        date_str = date_str.replace("-", "/")

        # Split the detected date into components
        components = re.split(r"[\/\-]", date_str)
        if len(components) != 3:
            return None  # Invalid format
        
        # Extract day, month, and year components
        day, month, year = components
        
        # Handle day
        if len(day) > 2 or int(day) > 31:
            day = 31
        else:
            day = int(day)

        # Handle month
        if len(month) > 2 or int(month) > 12:
            month = 1
        else:
            month = int(month)

        # Handle year
        year = int(year)
        #print(f"Year: {year}")
        if year < 100:  # Handle two-digit years
            year += 2000 
    
        #print(f"Corrected Date {date_str}: {day}/{month}/{year}")
        # Validate and return the date
        try:
            corrected_date = datetime(year, month, day)
        except ValueError:
            # Assign to 31/01/YYYY if invalid
            corrected_date = datetime(year, 1, 31)

        # Return the corrected date in DD/MM/YYYY format
        return corrected_date.strftime("%d/%m/%Y")
    except Exception as e:
        print(f"Error validating date {date_str}: {e}")
        return None


# Set up Google Vision API client
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "./client_secret_288127297142-8v4qgubcp78rol322tjlvrjdpfhevruo.apps.googleusercontent.com.json"  # Update with your JSON key path
client = vision.ImageAnnotatorClient()
# get fincail year based on date
from datetime import datetime

def get_financial_year(date):
    """
    Determines the financial year based on the given date.
    Financial year starts on April 1 and ends on March 31.
    
    :param date: Date string in the format "DD-MM-YYYY" or "DD/MM/YYYY"
    :return: A string representing the financial year, e.g., "2023-2024"
    """
    # Handle both "-" and "/" as separators
    date = date.replace("/", "-")
    
    # Parse the date
    parsed_date = datetime.strptime(date, "%d-%m-%Y")
    
    # Extract year, month
    year = parsed_date.year
    month = parsed_date.month
    
    # Determine financial year
    if month >= 4:  # From April to December
        start_year = year
        end_year = year + 1
    else:  # From January to March
        start_year = year - 1
        end_year = year
    
    return f"{start_year}-{end_year}"

# Test the function
#print(get_financial_year("15-05-2023"))  # Output: "2023-2024"
#print(get_financial_year("31/03/2023"))  # Output: "2022-2023"

# Function to extract number after keywords
def extract_delayed_number(text, keywords):
    lines = text.splitlines()  # Split text into lines
    for keyword in keywords:
        for i, line in enumerate(lines): 
            if re.search(keyword, line, re.IGNORECASE):  # Match keyword
                # Check subsequent lines for numbers
                for j in range(i + 1, len(lines)):
                    match = re.search(r"\b\d+\b", lines[j])  # Match standalone number
                    if match:
                        return match.group(0)  # Return the first matched number
    return None

def extract_and_highlight_text(image_path):
    try:
        # Load the image
        with open(image_path, 'rb') as image_file:
            content = image_file.read()

    
        image = vision.Image(content=content)
        response = client.text_detection(image=image)

        # Parse text detection response
        if response.error.message:
            raise Exception(f"Google Vision API error: {response.error.message}")

        annotations = response.text_annotations
        if not annotations:
            print(f"No text found in {image_path}")
            return None, None, None, None, None , None

        # Full extracted text
        extracted_text = annotations[0].description
        #print(f"Extracted Text UNCLEN: {extracted_text}")
        # Check if DOCKET NUMBER is in the extracted text and consignment_number is None or invalid
        IS_DOCET_NUMBER = False
        if re.search(r"DOCKET\s*NUMBER", extracted_text, re.IGNORECASE):
         IS_DOCET_NUMBER = True
        IS_CONSIGNMENT_NOTE = False
        if re.search(r"CONSIGNMENT\s*NOTE", extracted_text, re.IGNORECASE):
            IS_CONSIGNMENT_NOTE = True

        company_name = fetch_company_name(extracted_text)
        isSeparateImage = isSeparateThisImage(extracted_text)
       
        #sys.exit()
        #print("company_name " + company_name)
        #sys.exit()

        extracted_text = clean_text(extracted_text,IS_DOCET_NUMBER,company_name,isSeparateImage)

        CONSIGNMENT_DATE = None
        # Fetch the date
        try:
            date_found = fetch_single_date_and_validate(extracted_text)
            if date_found:
             #print(f"Matched Date: {date_found}")
             CONSIGNMENT_DATE = date_found
            else:
             pass
        except Exception as e:
            pass

        extracted_text = clean_dates_from_text(extracted_text)
        #print(f"Extracted Text: {extracted_text}")

        #print(f"IS_CONSIGNMENT_NOTE {IS_CONSIGNMENT_NOTE}")
        #print(f"Extracted Text: {extracted_text}")
        
        # Search for consignment numbers
        consignment_number = None
        IS_GRN = None
       
        primary_patterns = [
            r"AGR-\d+",
            r"PLK-\d+",
            r"PNP-\d+",
            r"SGN-\d+",
            r"MTH-\d+",
            r"GZB-\d+",
            r"GZB1-\d+",
            r"ALG-\d+",
            r"FBD-\d+",
            r"ZYS-\s*\d+",
           
            r"PNP-\d+",
            r"MZN-\d+",
            r"BLT-\d+",
            r"DDN-\d+",
            r"NDA-\d+",
            r"ZYS-\d+",
            r"DRL-\d+",
            r"PLK-\s*\d+",
            r"ZYS-\s*\d+",
            r"PNP-\s*\d+",
            r"SGN-\s*\d+",
            r"MTH-\s*\d+",
            r"GZB-\s*\d+",
            r"ALG-\s*\d+",
            r"FBD-\s*\d+",
            r"AGR-\s*\d+",
            r"PNP-\s*\d+",
            r"MZN-\s*\d+",
            r"BLT-\s*\d+",
            r"DDN-\s*\d+",
            
            r"NDA-\s*\d+",
            r"DRL-\s*\d+",
            
            r"DDR-\d+",
            r"DDR-\s*\d+",
            r"PLK-\d+",
            r"PLK-\s*\d+",
            r"PNP-\d+",
            r"PNP-\s*\d+",
            r"SGN-\d+",
            r"SGN-\s*\d+",
            r"MTH-\d+",
            r"MTH-\s*\d+",
            r"GZB-\d+",
            r"GZB-\s*\d+",
            r"ALG-\d+",
            r"ALG-\s*\d+",
            r"FBD-\d+",
            r"FBD-\s*\d+",
            r"AGR-\d+",
            r"AGR-\s*\d+",
            r"MZN-\d+",
            r"MZN-\s*\d+",
            r"BLT-\d+",
            r"BLT-\s*\d+",
            r"DDN-\d+",
            r"DDN-\s*\d+",
            r"NDA-\d+",
            r"NDA-\s*\d+",
            r"DRL-\s*\d+",
            r"ZYS-\d+",
            r"ZYS-\s*\d+",
            
        ]
        
        for pattern in primary_patterns:
            match = re.search(pattern, extracted_text, re.IGNORECASE)
            if match:
                consignment_number = match.group(0)
                #print(f"Matched Consignment Number: {consignment_number}")
                if '-' in consignment_number:
                    second_part = consignment_number.split('-')[-1]
                    #print(f"second_part {second_part} LEN {len(second_part)}")
                    if len(second_part) < 3:
                        consignment_number = None
                    else:
                        first_part = consignment_number.split('-')[0]
                        consignment_number = f"{first_part}-{second_part.strip()}"
                        break
                #elif numarib
                elif not consignment_number.isdigit():
                    consignment_number = None
                

        #print(f"Consignment Number: {consignment_number}")
        #SECON_EXTRACTION_START_TIME = time.time()
        # Search for consignment numbers using regex if consignment_number is None
        if not consignment_number:
            #print("Second Extraction")
            # EXCLUDED LIST: Words to exclude if matched
            EXCLUDED_LIST = ['NO', 'NUMBER', 'NO.', 'ied]', 'NO', 'NE.', 'Ne', 'No', 'Te', 'NOTICE', 'JAG', 'GSTIN', 'the', 'of', 'and', 'DATED','EWB. No.']

            
            # Patterns
            # Patterns to search for
            patterns = [
                r"CONSIGNMENT NOTE\s*\n\s*(\d{3,7})", # Matches
                r"CONSIGNMENT\s*NOTE\s*[:\-]?\s*(\d+)",  # Matches "CONSIGNMENT NOTE" optionally followed by ':' or '-' and then a number
                r"CONSIGNMENT\s*NOTE\s*No\.?\s*(\d+)",
                r"DOCKET NUMBER\s*\n\s*(\d{5})",
                r"DOCKET\s*NUMBER\s*[:\-]?\s*(\d{5}+)",  # Matches "DOCKET NUMBER" optionally followed by ':' or '-' and then a number
                r"DOCKET\s*NUMBER\s*[:\-]?\s*(\d{5}+)",  # Matches "DOCKET NUMBER" optionally followed by ':' or '-' and then a number
                r"GRN.*?\b(\d{4,7})\b", # Regex to match a number after "GRN" of length 4 to 7
                r"GRN.\s*[:\-]?\s*(\d+)",  # Matches "GRN" followed by a number
                r"GRN\s*[:\-]?\s*(\d+)",  # Matches "GRN" followed by a number
                r"GRIN.\s*[:\-]?\s*(\d+)",  # Matches "GRN" followed by a number
                r"GRIN\s*[:\-]?\s*(\d+)",  # Matches "GRN" followed by a number
                r"GR\. No\.:.*?\n.*?\n.*?(\d{3,7})", # Regex pattern to capture the 4-digit number below "GR. No.:"
                r"(\d{6,7})\s*[Gg][Rr][Nn]\.",  # Matches 6-8 digit numbers followed by "GRN." (case-insensitive)
                r"(\d{6,7})\s*[Gg][Rr][Nn]",  # Matches 6-8 digit numbers followed by "GRN" (case-insensitive)
                r"(\d{6,7})\s*[Gg][Rr]\b",    # Matches 6-8 digit numbers followed by "GR" (case-insensitive)
                r"G\.R\.\s*No\.\s*[:\-]?\s*(\d+)",  # Matches "G.R. No." followed by a number
                r"G\.R\.\s*No\.\s*(\d+)",  # Matches "G.R. No." followed by a number
                r"GR\.?\s*No\.?\s*[:\-]?\s*(?:\n\s*[A-Za-z]*)*\s*(\d{4,9})",  # Matches "GR. No." optionally followed by ':' or '-' and then a number
                r"(\d{4,7})\s*GR\.?\s*No\.?",
                r"(\d{4,7})\s*\n(?:[^\S\r\n]*[A-Za-z]+)?\s*\n\s*Date:",
                r"(\d{4,7})(?:\s*\n\s*\d{1,9})*\s*\n\s*G\.R\. No\.?:",
                r"(\d{4,7})\s*\n\s*(?:Date|DATED)",  # Matches 6-8 digit number directly above "Date" or "DATED"
               
                r"NO\.?\s*[:\-]?\s*(\d+)",
                r"(?<!EWB\.\s)GR\.?\s*NO\.?\s*[:\-]?\s*\n?\s*(\d+)",  # Multiline "GR. NO." followed by a number
                r"DATED\s*[:\-]?\s*\n\s*(\d+)",  # Matches only numbers on the next line after "DATED"
                r"DATED\s*\n\s*(\d+)",
                r"(?<!EWB\.\s)G\.R\.\s*No\.\s*:\s*Dated\s*:\s*(\d+)",
                r"(?:Date|DATED)\s*[:\-]?\s*(\d{3,9})",  # Matches "Date" or "DATED" followed by a 6-8 digit number
            
            ]
            i = 0
            for pattern in patterns:
                #i += 1
                #print(f"Pattern {i}: {pattern}")
                match = re.search(pattern, extracted_text, re.IGNORECASE)
                if match:
                    #print(f"Matched: {match.group(0)} {pattern} ")
                    consignment_number = match.group(0)
                    consignment_number = clean_consignment_number(consignment_number)
                    #print(f"Consignment Number: {consignment_number}")
                    # if length is less not between 6-12 then continue
                    if not consignment_number or len(consignment_number) < 3 or len(consignment_number) > 9 :
                        continue

                    
                    
                    #sys.exit()

                    # if pattern contains EWB. No. as prefix then continue
                    if re.search(r"EWB.\s*No.\s*[:\-]?\s*", consignment_number):
                        continue

                    
                    consignment_number_length = len(consignment_number)
                    # IF LENGHT IS >8 AND IS NUMBERS THEN RETURN NONE
                    if consignment_number_length > 9 and consignment_number.isdigit():
                        #print(f"Cleaned Consignment Number cat: {consignment_number}")
                        continue

                    # is IS_DOCET_NUMBER is True or company name is jag and length is > 6
                    if IS_DOCET_NUMBER and company_name == 'jag' and consignment_number_length  != 5:
                        #print(f"Cleaned Consignment Number dog: {consignment_number}")
                        continue
                    

                    # Additional numeric validation
                    try:
                        #print(f"Consignment Number CAT: {consignment_number}")
                        # cheack if it is not a date if date go to next
                        if re.search(r"\d{1,2}\/\d{1,2}\/\d{2,4}", consignment_number):
                            continue

                        # cha
                        
                        break
                    except Exception as e:
                        #print(f"Error processing consignment number: {e}")
                        consignment_number = None
        
        #SECON_EXTRACTION_END_TIME = time.time()
        #print(f"Time taken to extract consignment number using regex: {SECON_EXTRACTION_END_TIME - SECON_EXTRACTION_START_TIME:.2f} seconds")
        #print(f"Consignment Number: {consignment_number}")
        #print(f"company_name: {company_name}")
        cheack = None
        if consignment_number and isSeparateImage in ['GRF', 'VTC']:
            consignment_number = f"{isSeparateImage}-{consignment_number}"

        if company_name=='org' and consignment_number and consignment_number.isdigit():
            #get fist DIGIT OF CONSIGNMENT NUMBER
            consignment_number_first_digit = int(consignment_number[0])
            #print(f"Consignment Number First Digit: {consignment_number_first_digit}")
            if consignment_number_first_digit==0:
                # attach 1 at the start of consignment number
                consignment_number = '1' + str(consignment_number)
            #print(f"Consignment Number: {consignment_number}")
            
        if consignment_number and not isSeparateImage:
           cheack = fetch_gr_no_from_table(consignment_number, company_name,isSeparateImage,CONSIGNMENT_DATE)
           if not cheack:
               extracted_text = clean_text_from_removal_list(extracted_text, [consignment_number])
        #print(f" cheack {cheack}")
        if not IS_DOCET_NUMBER and ( not consignment_number or not cheack):
         consignment_number = fetch_number_near_gr_no(extracted_text)
         if not consignment_number:
            patterns = [
                r"GR\.?\s*No\.?.*?(\b\d{4,7}\b)"         # Matches numbers on the same line as "GR. No."
            ]
            # Search for the pattern in the extracted text
            for pattern in patterns:
                match = re.search(pattern, extracted_text, re.IGNORECASE | re.DOTALL)
                if match:
                    consignment_number =  match.group(1)
                    #print(f"Matched: {consignment_number} {pattern}")
                    if consignment_number:
                        break
        #print(f"Consignment Number: {consignment_number}")
        if not IS_DOCET_NUMBER and not consignment_number:
            normalized_text = re.sub(r"\s+", " ", extracted_text)
            pattern = r"(\d{4,6})(?=.*GRN\.)"
            all_matches = re.findall(pattern, normalized_text, flags=re.IGNORECASE)
            if all_matches:
                consignment_number = all_matches[-1]
        #print(f"Consignment Number: {consignment_number}")
        if not IS_DOCET_NUMBER and not consignment_number:
            normalized_text = re.sub(r"\s+", " ", extracted_text)
            pattern = r"GRN[:.]?\s*.*?\b(\d{4,6})\b"
            match = re.search(pattern, normalized_text, flags=re.IGNORECASE)
            if match:
                consignment_number = match.group(1)
        #print(f"Consignment Number: {consignment_number}")
        #sys.exit()
        # print image path
        #print(f"Image Path: {image_path}")
        if not IS_DOCET_NUMBER and ( not consignment_number or not cheack) and IS_CONSIGNMENT_NOTE and not isSeparateImage:          
            if consignment_number:
                extracted_text = clean_text_from_removal_list(extracted_text, [consignment_number])
            # Remove excessive whitespace and limit text to relevant content
            normalized_text = " ".join(extracted_text.split()[:500])  # Keep the first 500 words to reduce size
            pattern = r"CONSIGNMENT NOTE.*?\b(\d{3,7})\b"  # Look for 'CONSIGNMENT NOTE' followed by a number
            match = re.search(pattern, normalized_text, flags=re.IGNORECASE)
            if match:
                #print(f"Matched2: {match.group(0)}")
                consignment_number = match.group(1)
                if not isSeparateImage:
                    cheack = None
                    if consignment_number and isSeparateImage in ['GRF', 'VTC']:
                        consignment_numberCheack = f"{isSeparateImage}-{consignment_number}"
                    else:
                        consignment_numberCheack = consignment_number

                    cheack = fetch_gr_no_from_table(consignment_numberCheack, company_name,isSeparateImage,CONSIGNMENT_DATE)
                    #print(f" cheack {cheack}")
                    if not cheack:
                        extracted_text = clean_text_from_removal_list(extracted_text, [consignment_number])
                        #print(f"Extracted Text: {extracted_text}")
                        pattern =  r"CONSIGNMENT NOTE.*?\b(\d{3,7})\b"
                        match = re.findall(pattern, extracted_text)
                        if match:
                            #print(f"Matched3: {match}")
                            consignment_number = match[-1]



        #print(f"Consignment Number: {consignment_number}")   
        #print(f"Consignment Number CAT: {consignment_number}")
        if  IS_DOCET_NUMBER and ( not consignment_number or len(consignment_number) < 5 ):
                #print(f"Consignment Number CAT: {consignment_number}")
                patternSearch =  r"DOCKET NUMBER.*?\b(\d{5})\b"
                match2 = re.search(patternSearch, extracted_text, re.IGNORECASE | re.DOTALL)
                #print(f"Matched: {match2.group(0)}")
                if match2:
                    #print(f"Extracted Number CAT: {match2.group(1)}")
                    consignment_number = match2.group(1)  # Return the first matched number  
                else:
                    consignment_number = None
        #print(f"Consignment Number CAT: {consignment_number} IS_DOCET_NUMBER {IS_DOCET_NUMBER}")
        
        if IS_DOCET_NUMBER and company_name=='jag'  and ( not consignment_number or  len(consignment_number) != 5):
            consignment_number = None

        #print(f"Consignment Number CAT 1: {consignment_number}")
        
        if (not consignment_number or len(consignment_number) < 5) and IS_DOCET_NUMBER:
            #print("DOCKET NUMBER FOUND")
            
            # Pattern to fetch the number directly above "DATE"
            patterns = [
                r"(\d+)\s*DATE",
                r"DOCKET\s*NUMBER.*?DATE.*?\b(\d{5}+)\b",
                r"DOCKET\s*NUMBER.*?\n.*?\b(\d{5})\b",
                r"(\b\d{5}\b)(?=\s*\n.*?DOCKET\s*NUMBER)"
            ]
            # Search for the pattern in the extracted text
            for pattern in patterns:
                match = re.search(pattern, extracted_text, re.IGNORECASE | re.DOTALL)
                if match:
                    consignment_number = match.group(1)
                    if len(consignment_number) != 5:
                        continue
                    #print(f"Matched: {match.group(0)}")
                    #print(f"Extracted Number: {match.group(1)}")
                    break
        
        #print(f"Consignment Number CAT 2: {consignment_number}")
        CONSIGNMENT_DATE = None
        # Fetch the date
        try:
            date_found = fetch_single_date_and_validate(extracted_text)
            if date_found:
             #print(f"Matched Date: {date_found}")
             CONSIGNMENT_DATE = date_found
            else:
             pass
        except Exception as e:
            pass
            #print(f"Error fetching date: {e}")
            #print("No valid date found.")
        #print(f"Consignment Number CAT 3: {consignment_number}")
        # trim consignment number
        if consignment_number:
         consignment_number = consignment_number.strip()
        #print(f"Consignment Number CAT 3: {consignment_number}")
        #consignment_number_length = len(consignment_number)
        # IF LENGHT IS >8 AND IS NUMBERS THEN RETURN NONE
        
        
        if company_name=='org' and consignment_number and consignment_number.isdigit():
            #get fist DIGIT OF CONSIGNMENT NUMBER
            consignment_number_first_digit = int(consignment_number[0])
            #print(f"Consignment Number First Digit: {consignment_number_first_digit}")
            if consignment_number_first_digit==0:
                # attach 1 at the start of consignment number
                consignment_number = '1' + str(consignment_number)
        

        if consignment_number and len(consignment_number) > 9 and consignment_number.isdigit():
            return None, None, CONSIGNMENT_DATE , company_name, extracted_text, isSeparateImage

        #print(f"Consignment Number CAT 4: {consignment_number}")
        if consignment_number and len(consignment_number) >= 3:
            #print(f"Consignment Number CAT: {consignment_number} {pattern}")
            # cheack from table
            #print(f"Consignment Number CAT: {consignment_number}")
            # log the consignment number
            # fetch from table
            #sys.exit()
            #print(found_db);
            
            response = (consignment_number , IS_DOCET_NUMBER , CONSIGNMENT_DATE, company_name, extracted_text,isSeparateImage)
            return  response
            
        else:
            #print("No consignment number found.")
            response = (None, IS_DOCET_NUMBER, CONSIGNMENT_DATE, company_name, extracted_text, isSeparateImage)
            return response

       

    except Exception as e:
        #print(f"Error processing {image_path}: {e}")
        try:
            # ...existing code...
            if not CONSIGNMENT_DATE:
                # Handle the case where CONSIGNMENT_DATE is not set
                pass
            # ...existing code...
        except Exception as e:
            # Handle exceptions
            raise Exception(f"Google Vision API error: {response.error.message}")
            CONSIGNMENT_DATE = None
        return None, None, None, CONSIGNMENT_DATE, extracted_text, isSeparateImage

# Process directories in the current directory
log_file = "log.txt"
current_dir = os.getcwd()
subdirs = [os.path.join(current_dir, d) for d in os.listdir(current_dir) if os.path.isdir(os.path.join(current_dir, d))]
for subdir in subdirs:
    image_dir = os.path.join(subdir, "undetected")
    if not os.path.exists(image_dir):
        continue

    print(f"\nProcessing directory: {subdir}")
    FILE_PROCESSED = 0
    CONSIGNMENT_NUMBER_FOUND = 0
    DATE_FOUND = 0
    COMPANY_NAME_FOUND = 0

    for filename in os.listdir(image_dir):
        file_path = os.path.join(image_dir, filename)

        if os.path.isfile(file_path) and filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
            #print(f"Processing {file_path}...")
                 
            #print(f"IS DIRECT: {is_direct}")
            # start time 
            
            consignment_number, IS_DOCET_NUMBER, CONSIGNMENT_DATE, company_name, extracted_text, isSeparateImage = extract_and_highlight_text(file_path)
            consignment_number2 = consignment_number
            CONSIGNMENT_DATE2 = CONSIGNMENT_DATE
            cheack = fetch_gr_no_from_table(consignment_number, company_name,isSeparateImage,CONSIGNMENT_DATE)
    
            if not cheack:
                consignment_number = None
                CONSIGNMENT_DATE = None
            else:
                consignment_number = cheack[0]
                CONSIGNMENT_DATE = cheack[1]

            print(f"Consignment Number: {consignment_number} {consignment_number2}, IS_DOCET_NUMBER: {IS_DOCET_NUMBER} , CONSIGNMENT_DATE: {CONSIGNMENT_DATE} {CONSIGNMENT_DATE2}, COMPANY_NAME: {company_name} , filename {filename.strip()} , isSeparateImage {isSeparateImage}")
            
            
            with open(log_file, 'a') as log:
                    log.write(f"Consignment Number: {consignment_number} {consignment_number2} , IS_DOCET_NUMBER: {IS_DOCET_NUMBER} , CONSIGNMENT_DATE: {CONSIGNMENT_DATE} {CONSIGNMENT_DATE2}, COMPANY_NAME: {company_name} , filename {filename.strip()} \t isSeparateImage {isSeparateImage} \t\n")
                
            FILE_PROCESSED += 1
            if company_name:
                COMPANY_NAME_FOUND += 1
            if CONSIGNMENT_DATE:
                DATE_FOUND += 1
            if consignment_number:
                CONSIGNMENT_NUMBER_FOUND += 1
                image_extension = os.path.splitext(filename)[1]
                if isSeparateImage:
                  company_folder = 'SEPRATE'
                else:
                  company_folder = company_name or 'DISCARD'
                if IS_DOCET_NUMBER:
                    company_folder = 'jag'

                financial_year = ''
                try:
                    if CONSIGNMENT_DATE:
                        financial_year = get_financial_year(CONSIGNMENT_DATE)
                except Exception as e:
                    print(f"Error processing financial year: {e}")

                #new_file_path = os.path.join(company_folder, f"{consignment_number}{image_extension}")
                #os.makedirs(os.path.dirname(new_file_path), exist_ok=True)
                # log in log file
                
                try:
                    if consignment_number:
                        new_file_path = handle_file_move(
                            isSeparateImage,
                            file_path,
                            company_folder,
                            financial_year,
                            consignment_number,
                            image_dir
                        )
                        #is_org = fetch_gr_no_IN_ORG_from_table(consignment_number, company_name)
                        #sys.exit()
                        # Update file path in the database
                       
                        #found_db = fetch_gr_no_from_table(consignment_number,company_name)
                        #if found_db:
                            #update_file_path_in_table(company_name, is_org, consignment_number, new_file_path,CONSIGNMENT_DATE)
                        image_path = file_path;
                    else:
                        new_file_path = ''
                        if(isSeparateImage):
                            # move file to SEPRATE folder
                            new_file_path = handle_file_move(
                                isSeparateImage,
                                file_path,
                                'SEPRATE',
                                financial_year,
                                filename,
                                image_dir
                            )
                        # Log failure to move
                except Exception as e:
                    print(f"Error processing file {file_path}: {e}")
            else:
                financial_year = ''
                try:
                    if CONSIGNMENT_DATE:
                        financial_year = get_financial_year(CONSIGNMENT_DATE)
                except Exception as e:
                    print(f"Error processing financial year: {e}")
                if(isSeparateImage):
                    # move file to SEPRATE folder
                    filename = consignment_number2 or filename
                    new_file_path = handle_file_move(
                        isSeparateImage,
                        file_path,
                        'SEPRATE',
                        financial_year,
                        filename,
                        image_dir
                    )
                else:
                    filename = consignment_number2 or filename
                    # Log failure to move
                    new_file_path = handle_file_move(
                        isSeparateImage,
                        file_path,
                        company_name,
                        financial_year,
                        None,
                        image_dir,
                        consignment_number2
                    )
            

print("\nSummary:")
print(f"Total Files Processed: {FILE_PROCESSED}")
print(f"Consignment Numbers Found: {CONSIGNMENT_NUMBER_FOUND}")
print(f"Dates Found: {DATE_FOUND}")
print(f"Company Names Found: {COMPANY_NAME_FOUND}")

 