import os
from PIL import Image

# Specify the minimum dimensions
MIN_WIDTH = 320 + 1
MIN_HEIGHT = 240 + 1

def delete_low_resolution_images(directory):
    """
    Recursively deletes all image files in the specified directory and its subdirectories
    that have resolutions less than the specified thresholds.

    Args:
        directory (str): The path to the directory to clean up.
    """
    for root, dirs, files in os.walk(directory):
        for filename in files:
            file_path = os.path.join(root, filename)
            try:
                # Open the file to check if it's an image
                with Image.open(file_path) as img:
                    # Check if the image dimensions are smaller than the thresholds
                    if img.width < MIN_WIDTH or img.height < MIN_HEIGHT:
                        print(f"Deleting {file_path} (Dimensions: {img.width}x{img.height})")
                        os.remove(file_path)
            except (IOError, FileNotFoundError):
                # Skip non-image files silently
                pass
            except Exception as e:
                # Log unexpected errors
                print(f"Unexpected error with file {file_path}: {e}")

# Get the current directory
current_dir = os.getcwd()

# Run the cleanup
delete_low_resolution_images(current_dir)

print("Completed cleaning up low-resolution images.")
